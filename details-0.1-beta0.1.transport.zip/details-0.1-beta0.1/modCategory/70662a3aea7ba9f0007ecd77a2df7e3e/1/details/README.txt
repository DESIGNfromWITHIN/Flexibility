#1 Install Wayfinder:

---------------------------------------

#2 Create a wayfinder_rowTpl chunk:

wayfinder_rowTpl
Wayfinder row template
<li[[+wf.id]][[+wf.classes]]><a href="[[+wf.link]]">[[+wf.linktext]]<br/><span>[[+wf.description]]</span></a>[[+wf.wrapper]]</li>