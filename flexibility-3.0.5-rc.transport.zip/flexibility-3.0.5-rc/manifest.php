<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 3.0.5-rc
http://flexibilitymodx.com/

This package is meant to be used once to quick-start MODX website projects. It will install a lot of things and provide a nice responsive MODX website based on the Foundation framework from ZURB.

-----------------------------------------------------------------------------------------------------------
!!! ATTENTION !!!
-----------------------------------------------------------------------------------------------------------

- The Slider items Template Variable (called \'multiItemsGrid\') will not work after install, you need to open the \'multiItemsGrid\' Template Variable, and re-save it.
Simply go to: \'Elements\' tree > \'Template Variables\' > \'Flexibility\' and open the \'multiItemsGrid\' Template Varibale.
Edit any field (like the name, remove the final \'e\' and retype it) and save the Template Varibale. Now the Slider Items option will work as expected.
- If you change or edit any Chunk, Snippet, Template Variable or Plugin that was included in the Flexibility package, please rename it! Or it will be overwritten on any future updates.
- Any needed packages (like Wayfinder) will be installed automatically by the Flexibility package. You will be able to update and edit any sub-packages at a later date.

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation 3.2" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP

-----------------------------------------------------------------------------------------------------------
QUICKSTART
-----------------------------------------------------------------------------------------------------------

1. Download and install Flexibility from the MODX package manager.

-----------------------------------------------------------------------------------------------------------
MANUAL INSTALL
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-3.0.5-rc.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, Flexibility will not override excisiting Resources.

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-3.0.5-rc.transport (12 december 2012)
====================================
- Changed UPDATE_OBJECT back to TRUE (xPDOTransport::UPDATE_OBJECT => true), this was not working... Will try to create a seperate update package to Flexibility.

flexibility-3.0.4-rc.transport (4 december 2012)
====================================
- Fixed Slider MIGX items (again)

flexibility-3.0.3-rc.transport (14 november 2012)
====================================
- Fixed Slider MIGX item, should work fine now

flexibility-3.0.2-rc.transport (6 november 2012)
====================================
- Flexibility is a Release Candidate now!
- Updated to Foundation 3.2
- Changed UPDATE_OBJECT to FALSE (xPDOTransport::UPDATE_OBJECT => false), should prevent overwriting content on existing Flexibility installs.
- Added slide content
- Updated formit to 2.1.2-pl
- Updated getresources to 1.5.1-pl
- Updated migx to 2.3.2-pl

flexibility-3.0.1-alpha.transport (3 september 2012)
====================================
- Updated to Foundation 3.1.1
- Tested for MODX Revolution 2.2.5-pl

flexibility-3.0.0-alpha.transport (16 august 2012)
====================================
- Updated to Foundation 3.0

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-3.0.5-rc/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a21242779a11735054325d3da463fbe1',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/f151722c51e655c20364ea0eac6e38c7.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3c8b95320185b80600fc723db7c65c1b',
      'native_key' => '3c8b95320185b80600fc723db7c65c1b',
      'filename' => 'xPDOTransportVehicle/641e19eff90d0edd3d0ee1c68fa7c731.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1791bb5bdb08f1a8b09329f198a4521f',
      'native_key' => '1791bb5bdb08f1a8b09329f198a4521f',
      'filename' => 'xPDOTransportVehicle/dfdf2ca5aa10b6bf5b9675eb697dbdb8.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a6c6166cda4aebe63de43629408197fb',
      'native_key' => 'a6c6166cda4aebe63de43629408197fb',
      'filename' => 'xPDOTransportVehicle/d77eecc1ac9f4085af999a202ef8cf31.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3ea697f6e042890989b91de9c1aaa20f',
      'native_key' => '3ea697f6e042890989b91de9c1aaa20f',
      'filename' => 'xPDOTransportVehicle/8d83f2dd20c8cc9cf85dc7ea06d7c449.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd2c17fb4d78b6b81bc3b3cd9ee076ac0',
      'native_key' => 'd2c17fb4d78b6b81bc3b3cd9ee076ac0',
      'filename' => 'xPDOTransportVehicle/2702b38443a59224a59b142fa147a6a1.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '36697c719988a93a8e455fc5b4301f3c',
      'native_key' => '36697c719988a93a8e455fc5b4301f3c',
      'filename' => 'xPDOTransportVehicle/767786709fb4badc8428dbd305c99163.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1352c90e1355624fe6a7b971965dc0da',
      'native_key' => '1352c90e1355624fe6a7b971965dc0da',
      'filename' => 'xPDOTransportVehicle/ead11eeca1e82de624ac1c4605268bf7.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fce20822e9fad5afc888195d8b5fb2ed',
      'native_key' => 'fce20822e9fad5afc888195d8b5fb2ed',
      'filename' => 'xPDOTransportVehicle/4afc9126ab6e338897a6e49702ea59e0.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '527aac4edc67094babebd10c9025375c',
      'native_key' => '527aac4edc67094babebd10c9025375c',
      'filename' => 'xPDOTransportVehicle/ab026bfb1d3f2a950d17f9773dea12ba.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6eafeaae73294a2d439ad698dcceda92',
      'native_key' => 1,
      'filename' => 'modCategory/ac0344969731d2d6c5eb0ad23f7d27a2.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e9b2a4ca644195577b35a044cc6db67a',
      'native_key' => 1,
      'filename' => 'modResource/f5050189b1cbcbd70dd221bebbb1166a.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f15a48ac5ac989c6e07748d1b35dd385',
      'native_key' => 2,
      'filename' => 'modResource/aa0cceec22f9411672b6836925e65ccb.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '07ec8873c4cd256d64adad6af06009cc',
      'native_key' => 3,
      'filename' => 'modResource/a6a6ff56a079424abcc44b55907007ff.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a1a0ce9125923964f1cabe95430bd30f',
      'native_key' => 4,
      'filename' => 'modResource/d916c9f9d16b4534865cbbc8fc0e79b2.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fb3c589c14d287bd176998eca223fa54',
      'native_key' => 5,
      'filename' => 'modResource/172db068d79f81ab160fa12a2be84182.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1115a818044ca522b1e1a316d93c0e51',
      'native_key' => 6,
      'filename' => 'modResource/a41189b16009e8782973ab4add272b79.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1722847d49c3a98fb88468d495627e33',
      'native_key' => 7,
      'filename' => 'modResource/f3a0916896bf59a99c0b7c30b246b990.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '31b8c8d0b42f74a926557433111f9f77',
      'native_key' => 8,
      'filename' => 'modResource/42bfbe67b38f04459480446ab62c37cf.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3ed4accbcc3398126cbffaacea1188ff',
      'native_key' => 9,
      'filename' => 'modResource/a9521517ea9b9c65eeeb978a21921311.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ca777acb05f77616fa105be61b414e45',
      'native_key' => 10,
      'filename' => 'modResource/4f0c7a9d8e0e4dbe1fe7951c37a5e5f3.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f1165679a3242dc6f651c673d7c6656e',
      'native_key' => 11,
      'filename' => 'modResource/f5297a2eb07bcbbd1b70399357111468.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '6a73a2272c9cce2aac56b1e18bdc8675',
      'native_key' => 12,
      'filename' => 'modResource/015db7f060405ed6751d632e7dcfea33.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'da43676cf7feb84ceaffcd61eb06ee23',
      'native_key' => 13,
      'filename' => 'modResource/aa6cccf5a575d108f60dd34519d051c6.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);