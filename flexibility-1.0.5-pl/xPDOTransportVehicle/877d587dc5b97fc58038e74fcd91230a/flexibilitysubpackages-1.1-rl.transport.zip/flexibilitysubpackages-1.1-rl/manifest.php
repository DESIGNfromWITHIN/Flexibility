<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '85d55a631904871dd6e5bea1f97caf4d',
      'native_key' => 'flexibilitysubpackages',
      'filename' => 'modNamespace/b639517fbcf18756fbf42f9b9ad0b92c.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b487c414fa542df2da429e1f3d3cbcca',
      'native_key' => 1,
      'filename' => 'modCategory/e259335d4018000dd4d4d8c163945c51.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'dbb3bd2f737fe59e0be950f0bd4d8c43',
      'native_key' => 'dbb3bd2f737fe59e0be950f0bd4d8c43',
      'filename' => 'xPDOTransportVehicle/c867b39c80e7d15de0ddddc650a5a016.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ce784b7ba58672c2227785b565965e42',
      'native_key' => 'ce784b7ba58672c2227785b565965e42',
      'filename' => 'xPDOTransportVehicle/b76fe503b6f7aecf8dc5a84caada121b.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7e1e39f01d6af564ae61832e4b038600',
      'native_key' => '7e1e39f01d6af564ae61832e4b038600',
      'filename' => 'xPDOTransportVehicle/5dc1bba7b2f0f30c213916e0b9a9b12d.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '853f0c1cd9ab80b59b109a208bed04b6',
      'native_key' => '853f0c1cd9ab80b59b109a208bed04b6',
      'filename' => 'xPDOTransportVehicle/09cae5e40f119c5fb8ee41fe351f9bb9.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0772a568714a343c3f171132cc359669',
      'native_key' => '0772a568714a343c3f171132cc359669',
      'filename' => 'xPDOTransportVehicle/b9359d0aa78babab987d8c8704c16ef1.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5518d7af9264e6cfc3d82d638ae85ed7',
      'native_key' => '5518d7af9264e6cfc3d82d638ae85ed7',
      'filename' => 'xPDOTransportVehicle/5a001ccf357e45971869277507dfc2bd.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a17896b6a585215969d57ffbd85fe158',
      'native_key' => 'a17896b6a585215969d57ffbd85fe158',
      'filename' => 'xPDOTransportVehicle/477fd57c53a81a7a432633ea877a6635.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '529df3c3f55db57d23399d5b559102b1',
      'native_key' => '529df3c3f55db57d23399d5b559102b1',
      'filename' => 'xPDOTransportVehicle/671337abf397cd38b38de357cb5b1179.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3292db1b61343b1834b20e50f3a6daef',
      'native_key' => '3292db1b61343b1834b20e50f3a6daef',
      'filename' => 'xPDOTransportVehicle/b20c7564d765f257dda65eb59ec044c8.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
  ),
);