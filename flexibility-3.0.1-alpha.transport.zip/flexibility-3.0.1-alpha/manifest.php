<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 3.0.1-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation 3.1.1" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-3.0.1-alpha.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-3.0.1-alpha.transport (3 september 2012)
====================================
- Updated to Foundation 3.1.1

flexibility-3.0.0-alpha.transport (16 august 2012)
====================================
- Updated to Foundation 3.0

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-3.0.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '76a3891e5117c67a0793fc6e35fa51af',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/b54ae4f3268b8fa640924bc6fe08fed7.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bbbc9fae3393f2f0371f942e26cf62be',
      'native_key' => 'bbbc9fae3393f2f0371f942e26cf62be',
      'filename' => 'xPDOTransportVehicle/a63bc472b513046d2633a44cac52b8e1.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6a6717a24bce29ae790e4190b07463f1',
      'native_key' => '6a6717a24bce29ae790e4190b07463f1',
      'filename' => 'xPDOTransportVehicle/3eb8264af0b33e3268ec9fc84b817428.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8ed8169fa79894255ca04428197b05a0',
      'native_key' => '8ed8169fa79894255ca04428197b05a0',
      'filename' => 'xPDOTransportVehicle/e0038ff1e7904d571e284340e90acdc9.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7392dd69bd0557dc6a6f8024cda8cf91',
      'native_key' => '7392dd69bd0557dc6a6f8024cda8cf91',
      'filename' => 'xPDOTransportVehicle/68798217f6eec6e1db74aa0456f984b1.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '03644fe184ab29da3db14786b06fb6ed',
      'native_key' => '03644fe184ab29da3db14786b06fb6ed',
      'filename' => 'xPDOTransportVehicle/1427ef3ae1bb60e358f033406c8af68c.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5a4fcfc9c8c298b8c009568e2ea07efe',
      'native_key' => '5a4fcfc9c8c298b8c009568e2ea07efe',
      'filename' => 'xPDOTransportVehicle/1eeebec32a25d5f49f02f5fe6cfa4f5f.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f25a3c63b076d7b9629dca7457db96ac',
      'native_key' => 'f25a3c63b076d7b9629dca7457db96ac',
      'filename' => 'xPDOTransportVehicle/fc6bfc4800d1aa73fa7df535a89e446e.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e787336902fb0d3d82bd13a19ecd2a72',
      'native_key' => 'e787336902fb0d3d82bd13a19ecd2a72',
      'filename' => 'xPDOTransportVehicle/d0349bd2687244da508802220d4665bc.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a1cc7d1fd2bc0d5a4d0c91d048ef37e8',
      'native_key' => 'a1cc7d1fd2bc0d5a4d0c91d048ef37e8',
      'filename' => 'xPDOTransportVehicle/ae76f28fcf89adf44dbde2f3b7575267.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '77f46db8e3d8c3b0b7a718965b712822',
      'native_key' => 1,
      'filename' => 'modCategory/6e0c95cc13f38538ef252b26a3752b83.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'df5843f3ad46e376d95074a7ec763155',
      'native_key' => 1,
      'filename' => 'modResource/3129ec031cf212bd7ee72956bbcb2567.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f63971a91f2188078808ef5059949e98',
      'native_key' => 2,
      'filename' => 'modResource/5b298410fff23e32d774093d7b1c2cce.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '9ca0d66b893e491ac395e8c535428f97',
      'native_key' => 3,
      'filename' => 'modResource/535587b6853527f172711efe4d3f4f72.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a930aeaab01ee8df1b08f436c29fd5e7',
      'native_key' => 4,
      'filename' => 'modResource/8b91e1fe70da7104cc07f4d4e7ee2c38.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3bf775606ce07fca7d58aeb941208a43',
      'native_key' => 5,
      'filename' => 'modResource/58ac0221d15c5dda8f319a7079d4c992.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '24d69032d0ea1018cda367467392b922',
      'native_key' => 6,
      'filename' => 'modResource/ce7d8ceaf4fbced2f9de2469582f14a3.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fdc6b64ba2e45fe6768773997c5c05a4',
      'native_key' => 7,
      'filename' => 'modResource/ebf1d42e68bf4c2451d114e843950873.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1a9fe65b2b0c638d81014b4e477d7abc',
      'native_key' => 8,
      'filename' => 'modResource/90eaf70a995ef7e8f90dabb007367a90.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e33587a97db0dd4765308f061b1ca61c',
      'native_key' => 9,
      'filename' => 'modResource/5ec2e691ab8c1c0e77da289baf773428.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '2e6c2444193285000b487c29cd954993',
      'native_key' => 10,
      'filename' => 'modResource/346801a99ecddb95b17f27f44cbf8e1b.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '041687ae02c6c843219159301afe3d1c',
      'native_key' => 11,
      'filename' => 'modResource/ebd49beb60fe6a3fe380db9b0968c224.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a71b520642952795007f3dce70896d22',
      'native_key' => 12,
      'filename' => 'modResource/aaa93fc06c034524ffcbc8991764ba4f.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4943059e73e648364c6c4a97c106fde7',
      'native_key' => 13,
      'filename' => 'modResource/366879ea3dc6a890acc410db362be3b7.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);