<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 3.0.1-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation 3.1.1" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-3.0.1-alpha.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-3.0.1-alpha.transport (3 september 2012)
====================================
- Updated to Foundation 3.1.1
- Tested for MODX Revolution 2.2.5-pl

flexibility-3.0.0-alpha.transport (16 august 2012)
====================================
- Updated to Foundation 3.0

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-3.0.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eaeae5fac0693880a574641d351265a6',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/2327ff616911a3122e52e4b2c2b9c69f.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1f974d4244aa4d51584c82ae1c84d1b5',
      'native_key' => '1f974d4244aa4d51584c82ae1c84d1b5',
      'filename' => 'xPDOTransportVehicle/321321f71e2c329b64db9054860aff8c.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '173f0bac749c4de48d3a25a065b1f9fa',
      'native_key' => '173f0bac749c4de48d3a25a065b1f9fa',
      'filename' => 'xPDOTransportVehicle/fc3b6abdc0d8d33ba3f4e7686f906d9d.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a4e2d3a497b826d7da8be6981e038043',
      'native_key' => 'a4e2d3a497b826d7da8be6981e038043',
      'filename' => 'xPDOTransportVehicle/0d7f9efa782ea7453cd573acafa42ad4.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bca3fdf71952c2d8240de39bcad466be',
      'native_key' => 'bca3fdf71952c2d8240de39bcad466be',
      'filename' => 'xPDOTransportVehicle/cea1a782ff57a5a5461a65fb2b70031f.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '20ba4af310d1f631489fb29b5a06e7e8',
      'native_key' => '20ba4af310d1f631489fb29b5a06e7e8',
      'filename' => 'xPDOTransportVehicle/8afe606e9801a3100a610b73b5b93d9d.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9a2b93974dbed29c56e69285620aa612',
      'native_key' => '9a2b93974dbed29c56e69285620aa612',
      'filename' => 'xPDOTransportVehicle/e40d3ef224b7c1bd90c8bc9b62536a33.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fe89025accea27e60a82bf88d0a450ce',
      'native_key' => 'fe89025accea27e60a82bf88d0a450ce',
      'filename' => 'xPDOTransportVehicle/87e555d1bac5d829c633ff1fd507aa92.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '72392bc18688147705ca5f9b874f2114',
      'native_key' => '72392bc18688147705ca5f9b874f2114',
      'filename' => 'xPDOTransportVehicle/4dd66f1e1251eb9ea04cfc9978118113.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3394eb102a82e49d8a2c51be432f3eda',
      'native_key' => '3394eb102a82e49d8a2c51be432f3eda',
      'filename' => 'xPDOTransportVehicle/cb7c47eed8758192e19b33a9b6e650fb.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd442bdb293adab6b4f812645a8fd543b',
      'native_key' => 1,
      'filename' => 'modCategory/7bf3456ae3e49f582c49b675d78ad3e4.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '44dffb5e550d309bc46965a2bd552731',
      'native_key' => 1,
      'filename' => 'modResource/f2312a1c085c7203b3f6482e3319724d.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '568a08017500eea4465582607c4de49a',
      'native_key' => 2,
      'filename' => 'modResource/99fe5c7220a9878f04d6595855683859.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '04327ba162054b38ffb321d745fc4144',
      'native_key' => 3,
      'filename' => 'modResource/5a56302a1a7b3be198941da3d0828b69.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '8f464ee40bc7de36b483ab1d6bfc3e9a',
      'native_key' => 4,
      'filename' => 'modResource/3e6d2d5f7f44702e8a8530e23aa627b2.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0c3e10a2ca0627e4de899e4cc8023f3f',
      'native_key' => 5,
      'filename' => 'modResource/f1af86d4924ab5634aee1ca044221cb1.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c6524e2672dd589b3c1b9efd436e31e8',
      'native_key' => 6,
      'filename' => 'modResource/5c6d503bf844f2d06bc61fea4ec18400.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '90ce165ce909da2bc5f0cd020516eb07',
      'native_key' => 7,
      'filename' => 'modResource/e001034d54136522a73ec654e506f236.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '657796e8a7382cbe4c0895f08345650b',
      'native_key' => 8,
      'filename' => 'modResource/8842c68a9107d8bcf0d99846c29de433.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a565f6f22c7097ac7e8172c0ba89bf9a',
      'native_key' => 9,
      'filename' => 'modResource/1fedf5700ece679394402c0fc4fba79d.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '041a9ae8d27c30e526c3622682417f12',
      'native_key' => 10,
      'filename' => 'modResource/b239cbf853034f1007333a9828305700.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e1fed904114a3308550e7778128856bb',
      'native_key' => 11,
      'filename' => 'modResource/85ef5b2660d1116cd467986ff51bfa32.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f0c5bd20e695441ebdca3e87688440cc',
      'native_key' => 12,
      'filename' => 'modResource/695220c3c5df7af432a61d9883812b56.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3c989b01aad7371cc71937db33578643',
      'native_key' => 13,
      'filename' => 'modResource/e2f779cf8c7b5527017def0c6fb480c5.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);