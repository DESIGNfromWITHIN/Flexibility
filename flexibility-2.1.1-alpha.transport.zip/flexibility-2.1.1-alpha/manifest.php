<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 2.1.1-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-2.1.1-alpha.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.1.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1b471534f8c17c17ca3517f439a2dc64',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/e6e40dcfd5fea1c8ae3b4b02689dc86d.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f5a829258b400dfd285ef01401328346',
      'native_key' => 'f5a829258b400dfd285ef01401328346',
      'filename' => 'xPDOTransportVehicle/5d19d16c48728128bac9bc82619a4559.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e663840b02b0c58897202de27bdd4afd',
      'native_key' => 'e663840b02b0c58897202de27bdd4afd',
      'filename' => 'xPDOTransportVehicle/2381b06f752ac725e655be6b831982b2.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4437545e9f629227dde507a212238d6d',
      'native_key' => '4437545e9f629227dde507a212238d6d',
      'filename' => 'xPDOTransportVehicle/4cc72dc038d6d1272564ff3c6726bcf6.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7bede877b87fc76889308acaadca5811',
      'native_key' => '7bede877b87fc76889308acaadca5811',
      'filename' => 'xPDOTransportVehicle/441a806092142a953308b4f23df74c0a.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '63631b7c725b36d3b4db2c46bf9b0fc5',
      'native_key' => '63631b7c725b36d3b4db2c46bf9b0fc5',
      'filename' => 'xPDOTransportVehicle/01301ef8c835660cbdfaf4d6a3ededa9.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ed97ef95522df93a3d2380594ebef368',
      'native_key' => 'ed97ef95522df93a3d2380594ebef368',
      'filename' => 'xPDOTransportVehicle/1271863679756abc10c408c3771e73fe.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '881e8a7555f6425069a5be56383ed9a8',
      'native_key' => '881e8a7555f6425069a5be56383ed9a8',
      'filename' => 'xPDOTransportVehicle/bb3461943cdc8ad563eaad86d3d58117.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f1639e2e142709adaad6220f3572d768',
      'native_key' => 'f1639e2e142709adaad6220f3572d768',
      'filename' => 'xPDOTransportVehicle/1acb0cab336736eec66e239ab50a28fe.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6c307b35699b1a8699b594b39cbf9c29',
      'native_key' => '6c307b35699b1a8699b594b39cbf9c29',
      'filename' => 'xPDOTransportVehicle/ac4ee109fda2f8f3a6eff1237fba048d.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6614035b718379d63b81916c8ea20d77',
      'native_key' => 1,
      'filename' => 'modCategory/8145e16e960a6eb74144d88d37782809.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c478bd0ca4e3298356a918666308595f',
      'native_key' => 1,
      'filename' => 'modResource/af04ed145ca5da1242c1231b82266eef.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ac328d6ab24d57b576591085a0f3674e',
      'native_key' => 2,
      'filename' => 'modResource/bc833370ebc8e4b60ab0a1c0c00e0bc2.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '7049be9e8f62b6b0d0c3c1571a73906a',
      'native_key' => 3,
      'filename' => 'modResource/0b7f4b9df856702febddfabdcfb69fdd.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '09aa3d749911725ca52255f316305603',
      'native_key' => 4,
      'filename' => 'modResource/90dfd4632c494a3e748ad19cc4ed0e8d.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '154324ffb408dd7ff4d5bcbe48a1c42a',
      'native_key' => 5,
      'filename' => 'modResource/47f0d331d5270a38a03db4d314ade113.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '62c7b075cbc9b351353aeaddef2d1815',
      'native_key' => 6,
      'filename' => 'modResource/2827a253dd556d15142dd6d68b3426c5.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'efe6489553aec387f7c9df8e4367e2c1',
      'native_key' => 7,
      'filename' => 'modResource/7d6ccc40d1731aee3fefbe08df43d024.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0994262650253086749723df3aa590ad',
      'native_key' => 8,
      'filename' => 'modResource/0636a0bd6f8c638835d1be96a705a750.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a9997d47cfbb0fcc03d28d42adb073a6',
      'native_key' => 9,
      'filename' => 'modResource/21fdb9a097f3779c07770e582acf4434.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '919455312280289f9ca6dff351dc8a71',
      'native_key' => 10,
      'filename' => 'modResource/1e8a923ef658d38c998a5f06013d2f68.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '89cdf9c251a1a52ca11b5fc99dd105b2',
      'native_key' => 11,
      'filename' => 'modResource/6e022c424cd23ea625b7af466ae15a22.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a2817b5b430e59b7b97acba63f839a4d',
      'native_key' => 12,
      'filename' => 'modResource/32ba064ac1a0cb8cb7904d3b8fb7d157.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c278cf1a69a51168b34e335043c68b93',
      'native_key' => 13,
      'filename' => 'modResource/5d8279986190e8fed701b2308e40c8b3.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);