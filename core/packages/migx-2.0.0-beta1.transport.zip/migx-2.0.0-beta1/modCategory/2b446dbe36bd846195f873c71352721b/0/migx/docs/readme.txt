--------------------
MIGX
--------------------
Version: 1.2.0
Author: Bruno Perner <b.perner@gmx.de>
--------------------

* MIGX (multiItemsGridTv for modx) is a custom-tv-input-type for adding multiple items into one TV-value and a snippet for listing this items on your frontend.
* It has a configurable grid and a configurable tabbed editor-window to add and edit items.
* Each item can have multiple fields. For each field you can use another tv-input-type.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/Bruno17/multiItemsGridTV/issues

