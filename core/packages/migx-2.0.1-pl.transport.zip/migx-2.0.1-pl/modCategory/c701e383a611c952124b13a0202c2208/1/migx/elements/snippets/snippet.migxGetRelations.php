<?php

$id = $modx->getOption('id',$scriptProperties,$modx->resource->get('id'));
$toPlaceholder = $modx->getOption('toPlaceholder',$scriptProperties,'');
$outputSeparator = $modx->getOption('outputSeparator',$scriptProperties,',');

$packageName = 'resourcerelations';

$packagepath = $modx->getOption('core_path') . 'components/' . $packageName . '/';
$modelpath = $packagepath . 'model/';

$modx->addPackage($packageName, $modelpath, $prefix);
$classname = 'rrResourceRelation';

$c = $modx->newQuery($classname,array('target_id'=>$id,'published'=>'1'));
$c->select($modx->getSelectColumns($classname));
//$c->prepare(); echo $c->toSql();
if ($c->prepare() && $c->stmt->execute()) {
    $collection = $c->stmt->fetchAll(PDO::FETCH_ASSOC);
}
foreach ($collection as $row) {
    $ids[]=$row['source_id'];
}
$output = implode($outputSeparator,$ids);

if (!empty($toPlaceholder)){
    $modx->setPlaceholder($toPlaceholder,$output);
    return '';
}

return $output;