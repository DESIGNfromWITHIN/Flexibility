<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b9c13b37e55e204b9b0c86d92c7b51a9',
      'native_key' => 'migx',
      'filename' => 'modNamespace/a0a4c72f6a2424da69cf6ff19a911bb8.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '29cf6d9cc200789d9629017316277b5a',
      'native_key' => 3,
      'filename' => 'modPlugin/0d63eb9b63d4e9d83d91889d4f636ff6.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bb081ea67867e116689e10ce6e81fd70',
      'native_key' => 1,
      'filename' => 'modCategory/f5a08e3857b348bd8c2b69f6f49c1df3.vehicle',
      'namespace' => 'migx',
    ),
  ),
);