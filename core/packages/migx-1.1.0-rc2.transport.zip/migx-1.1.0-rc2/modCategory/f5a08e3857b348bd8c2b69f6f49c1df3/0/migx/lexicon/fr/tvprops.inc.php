<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */


$_lang['mig.tabs'] = 'Onglets du formulaire';
$_lang['mig.columns'] = 'Colonnes de la grille';
$_lang['mig.btntext'] = 'Intitulé du bouton';
$_lang['mig.previewurl'] = 'Preview Url';
$_lang['mig.jsonvarkey'] = 'Preview JsonVarKey';