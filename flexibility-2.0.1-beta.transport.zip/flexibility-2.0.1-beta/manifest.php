<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.0-pl

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen (blog: http://designfromwithin.com - Twitter: MennoPP)


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-1.1.0-pl.transport.zip" and upload it to "your_url/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
Don\'t forget to setup FriendlyURL\'s:
-----------------------------------------------------------------------------------------------------------

1. Backup the "ht.access" file in from root folder to your desktop and remove the "ht.access" file from your website root (your root is probably something like: "your_url/public_html/").

2. Open the "ht.access" file from your desktop (with notepad or any code editor) and save it as ".htaccess".

3. Copy the new ".htaccess" file to your website root.

4. Enter your MODX Revolution manager ("your_url/manager"): Go to "System" > "System Settings" > Click on "Filter by area" and select "Friendly URL" > For "Use Friendly URL\'s" and "Use Friendly Alias Path" choose "Yes".

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Logo"

2. An e-mail adress where you want to get mail from the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "E-mail adress"

3. Your adress (remove the default text to keep it empty).
- Add this under "Resources" > "Site settings" > "Template Variables" > "Adress"


And three optional things (only if you want a slider and/or gallery and want custom template colors):

1. Slide content for your website slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"

2. Images and (optional) descriptions for your gallery.
- Add this under "Components" > "Gallery" > "Create Album"

I general you can find all website settings under:

"Resources" > \'select the page you want\'
"Resources" > \'select the page you want\' > "Template Variables"
"System" > "System Settings" > "Filter by area" > "Site"


-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"


-----------------------------------------------------------------------------------------------------------
IMPORTANT NOTICES FOR DEVELOPMENT:
-----------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but will be added....
- special thanks to: Paul Irish and Divya Manian for all they\'ve done with HTML5Boilerplate
- https://github.com/paulirish/html5-boilerplate for the initial base and idea
- https://github.com/modernizr for MOdernizr
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/


-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-1.0.7-pl.transport (31-07-2011)
====================================
- Added Babel package and updated the other packages.

flexibility-1.0.6-pl.transport (28-07-2011)
====================================
- Fixed a components/flexibility path error (thx Les Pfister)
- Fixed the email not being send bug (need MODX 2.1.3-pl)
- Thx for all the support guys!

flexibility-1.0.5-pl.transport (17-07-2011)
====================================
- Updated getResources to 1.3.1-pl
- Updated Login to 1.6.5-pl
- tested getResources settings for MODX 2.1.2-pl 

flexibility-1.0.4-rl.transport (11-07-2011)
====================================
- Removed unneeded col12 classes
- Removed padding from grid css
- Added padding_20_10 classes to divs
- Fixed 978px bug

flexibility-1.0.3-rl.transport (08-07-2011)
====================================
- Sub-packages are now listed and updatable after package install.
- Updated README.txt.
- Add warning about MODX Revo 2.1.2-pl not working with this package.

flexibility-1.0.1-rl.transport (24-06-2011)
====================================
- Changed js files for slider and gallery support

flexibility-1.0-rl.transport (20-06-2011)
====================================
DONE:
-----------------------------------------------------------------
- Started with GitHub
- MODx HTML5 Boilerplate used as a base for the template
- Main content hidden if no content added (using If add-on)
- Homepage blocks added, manageble with TV\'s
- Homepage blocks hidden if no block title added (using If add-on)
- Wayfinder navigation added
- jQuery slider added (NIVO Slider - http://nivo.dev7studios.com/)
- Slider with image, title, text, link and link-text TV\'s
- Hide/show slider TV added',
    'setup-options' => 'flexibility-2.0.1-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '38c02c6c122a572939be3ff857d39333',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/9e724d56ead6936f62fdecd030529c54.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5f5f98c5f0381f07f313f0da0f684cc5',
      'native_key' => '5f5f98c5f0381f07f313f0da0f684cc5',
      'filename' => 'xPDOTransportVehicle/71eadb7742bc3ff0d0932c97c5470fe0.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e271cd0f0f113c13fa4013f75bec1943',
      'native_key' => 'e271cd0f0f113c13fa4013f75bec1943',
      'filename' => 'xPDOTransportVehicle/c88446501b4895e562c0b406df7e1acc.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '558453345192210ef4643fc9b82a9996',
      'native_key' => '558453345192210ef4643fc9b82a9996',
      'filename' => 'xPDOTransportVehicle/a8c5fdf8eae732c80e00a17145143cf8.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6699226fcc40412794c2ebcbe85a4a1a',
      'native_key' => '6699226fcc40412794c2ebcbe85a4a1a',
      'filename' => 'xPDOTransportVehicle/efd686fe196f6877218cd9463df26553.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '887370d12ba3b4d90f5a8e35161fd971',
      'native_key' => '887370d12ba3b4d90f5a8e35161fd971',
      'filename' => 'xPDOTransportVehicle/5e3a979b46288e92cb95284a977ff984.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '58906acab18a28d0f112e03023df8a65',
      'native_key' => '58906acab18a28d0f112e03023df8a65',
      'filename' => 'xPDOTransportVehicle/cf70d08e5e69d0ab0bcb43d9c3f84725.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '55f6303c8aee6a59fa26b595f03b6791',
      'native_key' => '55f6303c8aee6a59fa26b595f03b6791',
      'filename' => 'xPDOTransportVehicle/6008736a278fd46a03c3dda36f2a77c7.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6a8f311a80eb09f55a0647cfc627e67b',
      'native_key' => '6a8f311a80eb09f55a0647cfc627e67b',
      'filename' => 'xPDOTransportVehicle/ee7f2f9a15f060bfbd81bfbb09d00120.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ca0d9f6dbb28f3bdd9e5e7afa3222c77',
      'native_key' => 'ca0d9f6dbb28f3bdd9e5e7afa3222c77',
      'filename' => 'xPDOTransportVehicle/8066241b7ea48d0c6786840d1947f6e2.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '05c37c56334bd71e05c04d0e9a2a8f85',
      'native_key' => 7,
      'filename' => 'modCategory/90bdc05b55e7db869b3dddecc5a44dda.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd13b759731c923676d61850b2b042dab',
      'native_key' => 1,
      'filename' => 'modResource/48765b7c4144e55c981e1266fe87dfda.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f63f07f6e610b62561b3829474c7368e',
      'native_key' => 2,
      'filename' => 'modResource/c891bc78dd20557a3405fc0274d82828.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '25d51d5b128ac39ed38062e447029e62',
      'native_key' => 3,
      'filename' => 'modResource/b7b4442e579fb87f49a5feb1885f1963.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e0247c167d4cf7475f1042ef42a2604c',
      'native_key' => 4,
      'filename' => 'modResource/59bfbc8fd71e4ca2e33790af53f6274d.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '6cddd4c5d6c25812987f728189d85d06',
      'native_key' => 5,
      'filename' => 'modResource/27c677ca5c672b0ea16ec72a758aa555.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e888643320c8a4b4e82551b4de9bae84',
      'native_key' => 6,
      'filename' => 'modResource/b1874280c6f4b1e00ace9379533fdcfa.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '84128848897edf80565fa545ff2dd1e2',
      'native_key' => 7,
      'filename' => 'modResource/850c4b58c8fc34dbeb267e35383f2e53.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '319b3d8dd7e63267a1ef68214929761a',
      'native_key' => 8,
      'filename' => 'modResource/65519d59cdd93dc444e6b4069ec07300.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'bb676eab7dae6fceffb5e53d86c9c1a0',
      'native_key' => 9,
      'filename' => 'modResource/bc9b4481079d3313c708d0f2970834ff.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ce0965536412189d80a72342efcfc3dc',
      'native_key' => 10,
      'filename' => 'modResource/b79989c26f7c183a34e8080497751096.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fa0cf67ac19cefd45d5344d78bb6d67b',
      'native_key' => 11,
      'filename' => 'modResource/6e7747a8711c1fc1dec3825675b4f679.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a0acae0bce16f18581b003add37a09ef',
      'native_key' => 12,
      'filename' => 'modResource/58dd959d72aabce10f7534d57ea876fe.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '43ee5ae3f56b9268f230629318e235da',
      'native_key' => 13,
      'filename' => 'modResource/bc47e2cf7d15cbb1199a3c0c774babe1.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);