<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */

//$_lang['mig_'] = '';


$_lang['mig_noitems'] = 'Keine Datensätze gefunden';
$_lang['mig_add'] = 'Datensatz erstellen';
$_lang['mig_remove_confirm'] = 'Datensatz entfernen?';
$_lang['mig_edit'] = 'Bearbeiten';
$_lang['mig_remove'] = 'Entfernen';
$_lang['mig_duplicate'] = 'Duplizieren';