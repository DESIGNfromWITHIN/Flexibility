<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */

//$_lang['mig_'] = '';


$_lang['mig_noitems'] = 'No items found';
$_lang['mig_add'] = 'Add Item';
$_lang['mig_remove_confirm'] = 'Remove Item?';
$_lang['mig_edit'] = 'Edit';
$_lang['mig_remove'] = 'Remove';
$_lang['mig_duplicate'] = 'Duplicate';