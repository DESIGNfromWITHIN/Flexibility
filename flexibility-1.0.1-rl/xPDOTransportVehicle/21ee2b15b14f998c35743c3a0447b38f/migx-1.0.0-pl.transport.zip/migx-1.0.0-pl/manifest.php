<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8e86d9a38e56d710595d88f81d842212',
      'native_key' => 'migx',
      'filename' => 'modNamespace/513bc53920426afd897789fd93738502.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'a07ef52e71fe46d1751ef010f1161937',
      'native_key' => 3,
      'filename' => 'modPlugin/be8611b7fffb32e89cbe889b77f3e129.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3f7783773f1da1d3189e6a976cbb7500',
      'native_key' => 1,
      'filename' => 'modCategory/f425aa0dd529ae632f424a4511a2366e.vehicle',
      'namespace' => 'migx',
    ),
  ),
);