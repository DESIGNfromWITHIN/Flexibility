tinyMCE.addI18n('be.modxlink',{
    link_desc:"Insert/edit link"
});