tinyMCE.addI18n('zu.modxlink',{
    link_desc:"Insert/edit link"
});