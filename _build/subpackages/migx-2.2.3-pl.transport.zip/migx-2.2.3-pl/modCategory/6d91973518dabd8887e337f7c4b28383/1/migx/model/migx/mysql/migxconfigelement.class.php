<?php
require_once (dirname(dirname(__FILE__)) . '/migxconfigelement.class.php');
class migxConfigElement_mysql extends migxConfigElement {}