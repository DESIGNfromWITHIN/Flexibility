<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'FlexibilitySubPackages - version 1.0-rl

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

All external subpackages need for the Flexibility template.

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "MODX Boilerplate".
With this package you will have a fully functional website with a contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen (blog: http://designfromwithin.com - Twitter: ThaClown)

NOTE:
"MODX Boilerplate" is created by Anselm Hannemann, and it is not a direct clone of the original HTML5Boilerplate by Paul Irish.

-----------------------------------------------------------------------------------------------------------
CONTENT:
-----------------------------------------------------------------------------------------------------------

- bloggingessentials-1.0-pl
- formit-1.7.0-pl
- gallery-1.2.1-pl
- getresources-1.3.0-pl
- if-1.1-pl
- login-1.6.4-pl
- migx-1.1.0-rc1
- tinymce-4.3.0-rc2
- wayfinder-2.3.1-pl',
    'changelog' => 'Changelog for FlexibilitySubPackages

FlexibilitySubPackages - version 1.0-rl (08-07-2011)
====================================
- Started this concept: Package needed sub-packages with packman, install this with my own custom script.
Many thanks to: Romain Tripault (Twitter @rtripault) for the tip!',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd3e77185215be7534fa958568ff40c4d',
      'native_key' => 'flexibilitysubpackages',
      'filename' => 'modNamespace/da683c69c75ebb160da12b875a977c2c.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3c0dfdebf76ce2e7c2185b5b94aca835',
      'native_key' => 1,
      'filename' => 'modCategory/0a78ab07877c1db7f1f20d11931c36a3.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4a32343aa76310c1e22d7f242c4e8fea',
      'native_key' => '4a32343aa76310c1e22d7f242c4e8fea',
      'filename' => 'xPDOTransportVehicle/147246df29c33ad8824dd18603c2724c.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'abaa7765f241e9ac1debbb2e38df1037',
      'native_key' => 'abaa7765f241e9ac1debbb2e38df1037',
      'filename' => 'xPDOTransportVehicle/38972f5d9078a27fdde6ff3e70297bdb.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '55ac6c1f14c8d699c247879e32d9bf6c',
      'native_key' => '55ac6c1f14c8d699c247879e32d9bf6c',
      'filename' => 'xPDOTransportVehicle/84080f976ebe6c923585ab99929f0d6f.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '497a917885e5bae63d059476cba4332f',
      'native_key' => '497a917885e5bae63d059476cba4332f',
      'filename' => 'xPDOTransportVehicle/6519a8355b71ce94e46e53516ec14147.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2be6478db4e41df4fb8a839ccd263896',
      'native_key' => '2be6478db4e41df4fb8a839ccd263896',
      'filename' => 'xPDOTransportVehicle/c7271dfe577e9abdba85d912ed1100c2.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '91932241a00ffcebfac8f4fd1f8993b9',
      'native_key' => '91932241a00ffcebfac8f4fd1f8993b9',
      'filename' => 'xPDOTransportVehicle/b39f73e70d82c3631c122c53da2a9bca.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8a056573e374a6fb252182eb68dbed17',
      'native_key' => '8a056573e374a6fb252182eb68dbed17',
      'filename' => 'xPDOTransportVehicle/9bf9e27defcb24b863b63eff344c2d6c.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '751b343901a1e8604c7f6b7bef77fd46',
      'native_key' => '751b343901a1e8604c7f6b7bef77fd46',
      'filename' => 'xPDOTransportVehicle/081e370a92535e2f23a4c6f042578906.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9b9966459605796faa60121173f74284',
      'native_key' => '9b9966459605796faa60121173f74284',
      'filename' => 'xPDOTransportVehicle/94c37e26d581f722b5fedbdab890c804.vehicle',
      'namespace' => 'flexibilitysubpackages',
    ),
  ),
);