tinyMCE.addI18n('cs.modxlink',{
    link_desc:"Insert/edit link"
});