<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'galItem',
    1 => 'galAlbum',
    2 => 'galAlbumItem',
    3 => 'galAlbumContext',
    4 => 'galTag',
  ),
  'modMediaSource' => 
  array (
    0 => 'GalleryAlbumsMediaSource',
  ),
);