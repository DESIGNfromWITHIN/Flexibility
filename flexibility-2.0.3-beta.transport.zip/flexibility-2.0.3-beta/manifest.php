<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.3-beta

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen (blog: http://designfromwithin.com - Twitter: MennoPP)


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-2.0.3-beta.transport" and upload it to "your_url/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Logo"

2. An e-mail adress where you want to get mail from the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but will be added....
- special thanks to: Paul Irish and Divya Manian for all they\'ve done with HTML5Boilerplate
- https://github.com/paulirish/html5-boilerplate for the initial base and idea
- https://github.com/modernizr for MOdernizr
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.3-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3c6de695d8bbdd83518b0a38573460fc',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/cf156b2db44161ee705bbe373008ca32.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6c0dbe00adab0c3a655b248aae102e39',
      'native_key' => '6c0dbe00adab0c3a655b248aae102e39',
      'filename' => 'xPDOTransportVehicle/e20a41148bdbd782b117c9b169d29122.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'aa7d466fe24d1756d6aa62131dac187c',
      'native_key' => 'aa7d466fe24d1756d6aa62131dac187c',
      'filename' => 'xPDOTransportVehicle/368cf37544c431d2d5d3a805eddae17f.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'dc61090b30735d3a15c85ed8ccd35a4e',
      'native_key' => 'dc61090b30735d3a15c85ed8ccd35a4e',
      'filename' => 'xPDOTransportVehicle/d04a7f672f3e72c37953f35f586f3c73.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2358604f5a2fbcd7bb1370d22a5bea6e',
      'native_key' => '2358604f5a2fbcd7bb1370d22a5bea6e',
      'filename' => 'xPDOTransportVehicle/455a155002b235e0dfb855f43ca60362.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '23bc91eac5c297971ca9b075744a0ef1',
      'native_key' => '23bc91eac5c297971ca9b075744a0ef1',
      'filename' => 'xPDOTransportVehicle/1426708896fb0b03952e91ad9290d978.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '49f928139bb7ae0e6c8731de68026a0e',
      'native_key' => '49f928139bb7ae0e6c8731de68026a0e',
      'filename' => 'xPDOTransportVehicle/d75dc130a9c0e96a559acbb08c4bdd1b.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5b025d322f4af8cd560a75e24deb88e2',
      'native_key' => '5b025d322f4af8cd560a75e24deb88e2',
      'filename' => 'xPDOTransportVehicle/94677a5c7c1918ba333905799856b467.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7273bb346675a140f96e77571f55a8d2',
      'native_key' => '7273bb346675a140f96e77571f55a8d2',
      'filename' => 'xPDOTransportVehicle/8b9d879cc2060f9cf28405cc1e751716.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3474d4c5b88fb59a3654e864041d6c83',
      'native_key' => '3474d4c5b88fb59a3654e864041d6c83',
      'filename' => 'xPDOTransportVehicle/274a093dc1703b2cfdb77c20b0de38f0.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b4cda7024f5a4b433f3f79d4fed6e6e6',
      'native_key' => 1,
      'filename' => 'modCategory/4fd75b97776f44c0bea18764e3077ef4.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1228f8791ce6723d0317607cdb865b34',
      'native_key' => 1,
      'filename' => 'modResource/5dc0809beae5374b3dd14d7a165f3135.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '2923b5ac3567d64e29074d681991f370',
      'native_key' => 2,
      'filename' => 'modResource/63ba95bd99ce2be6f2dcd95a1b99e08e.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'dc5365dbc9babad6a96a9c69900b192b',
      'native_key' => 3,
      'filename' => 'modResource/f1f5e5feb88e02869cf4c32a69fd806b.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'adeb624f6b1d15aab5c03752ef17f201',
      'native_key' => 4,
      'filename' => 'modResource/54f2bd1862d00a8b581c5497fcebe806.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '536298bdacf35088de802fcc5aa0c3cd',
      'native_key' => 5,
      'filename' => 'modResource/f0ec627528b9a6d9b540c426ae6ad430.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e0516e18950c0452abd21d9a69e6a8c8',
      'native_key' => 6,
      'filename' => 'modResource/431ff89417eaa25e21e1bbf3685c3001.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '79f2578fb443e21771456e97061bc3bf',
      'native_key' => 7,
      'filename' => 'modResource/bf1a4d9f5ec928959b28453c47ba9df0.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b6a8f9d11d0e1de4ca1f536919d420f5',
      'native_key' => 8,
      'filename' => 'modResource/963bced3698e2a8fcd2615d855e099cb.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e784833ba7806bfc4e3a6c6dc504b176',
      'native_key' => 9,
      'filename' => 'modResource/9b5258914c241da326cd5f52883bb8a7.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b2d6d9e0c573b0931301166eccfe1fd3',
      'native_key' => 10,
      'filename' => 'modResource/080fa9e5964257d49eaa425883e4b625.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '08bbc646562c30b050355ce10e177ecc',
      'native_key' => 11,
      'filename' => 'modResource/9991e28d4a1924fa0eafd16cefdc8b0e.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a325aebd5a79456f7f4748581637c49c',
      'native_key' => 12,
      'filename' => 'modResource/ead9cf26d2261379a203d95f7ccc337b.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '08486b86f7a7b2385787d3729ae3b111',
      'native_key' => 13,
      'filename' => 'modResource/35ec3a4a42bd2417a6ceb9ec2828c80d.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);