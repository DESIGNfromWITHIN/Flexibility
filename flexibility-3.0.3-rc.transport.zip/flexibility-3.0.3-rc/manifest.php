<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 3.0.3-rc
http://flexibilitymodx.com/

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation 3.2" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP

-----------------------------------------------------------------------------------------------------------
QUICKSTART
-----------------------------------------------------------------------------------------------------------

1. Download and install Flexibility from the MODX package manager.

-----------------------------------------------------------------------------------------------------------
MANUAL INSTALL
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-3.0.3-rc.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, Flexibility will not override excisiting Resources.

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-3.0.3-rc.transport (14 november 2012)
====================================
- Fixed Slider MIGX item

flexibility-3.0.2-rc.transport (6 november 2012)
====================================
- Flexibility is a Release Candidate now!
- Updated to Foundation 3.2
- Changed UPDATE_OBJECT to FALSE (xPDOTransport::UPDATE_OBJECT => false), should prevent overwriting content on existing Flexibility installs.
- Added slide content
- Updated formit to 2.1.2-pl
- Updated getresources to 1.5.1-pl
- Updated migx to 2.3.2-pl

flexibility-3.0.1-alpha.transport (3 september 2012)
====================================
- Updated to Foundation 3.1.1
- Tested for MODX Revolution 2.2.5-pl

flexibility-3.0.0-alpha.transport (16 august 2012)
====================================
- Updated to Foundation 3.0

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-3.0.3-rc/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1d946db03ca95d20edacdc839e4ad3f9',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/524b97bf5882ec68fcebef5cd8bb7d78.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '27366065f4178fcf4a1e1145a1ec6b2d',
      'native_key' => '27366065f4178fcf4a1e1145a1ec6b2d',
      'filename' => 'xPDOTransportVehicle/39b281f43d510ca1d6a08d7a13bba769.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c3f842593fe39247ac359121dfb4ab61',
      'native_key' => 'c3f842593fe39247ac359121dfb4ab61',
      'filename' => 'xPDOTransportVehicle/49b5a92b9b94898dd783ba223f884892.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd2892bcff7c93628afcf8c41f078fd16',
      'native_key' => 'd2892bcff7c93628afcf8c41f078fd16',
      'filename' => 'xPDOTransportVehicle/4af42332f7e1355069e539335874f437.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e6e088f545470f8ad73e894f5b1d7650',
      'native_key' => 'e6e088f545470f8ad73e894f5b1d7650',
      'filename' => 'xPDOTransportVehicle/64c6f59de759a2f4542b2a9f9c5274c2.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a7b1b031076da9c16e264a6790e5c3bc',
      'native_key' => 'a7b1b031076da9c16e264a6790e5c3bc',
      'filename' => 'xPDOTransportVehicle/e1846e68211ee3a85017db81de0e6e26.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2f8aa0626626eca0698275886dc5767e',
      'native_key' => '2f8aa0626626eca0698275886dc5767e',
      'filename' => 'xPDOTransportVehicle/5449b8b768cc768514198cc4c417278e.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6cc512c431236ae2fdc0f52e1c5fb6b1',
      'native_key' => '6cc512c431236ae2fdc0f52e1c5fb6b1',
      'filename' => 'xPDOTransportVehicle/05f6a1a601e42ad11c65fe21cda7c847.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '780e4200aa48a9ce40ee21b981d75c95',
      'native_key' => '780e4200aa48a9ce40ee21b981d75c95',
      'filename' => 'xPDOTransportVehicle/5de9fa68a281bf9ec30279d9b6b48086.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b9464bc3037034c115be4f4dbd394cd2',
      'native_key' => 'b9464bc3037034c115be4f4dbd394cd2',
      'filename' => 'xPDOTransportVehicle/5afc36a94d915a3849ae5504acec0cb7.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '185d2556284a041893acb2373314da10',
      'native_key' => 1,
      'filename' => 'modCategory/b70c2d5ef983cd303e4eb173bdcb0a45.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '70f2dab69e8ef04413e4255082619d6b',
      'native_key' => 1,
      'filename' => 'modResource/0d739f43bf75bc4899278b8ff22aa4cd.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e33b705884ad4fce118f1df18ca59384',
      'native_key' => 2,
      'filename' => 'modResource/e250f762235dcc299d00956a6674329e.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '335055d33b6d81961ec0b4d7970f224f',
      'native_key' => 3,
      'filename' => 'modResource/520f4f4e6e719c12e07a8e3aa8be4c53.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e99cae578fb318229c42b728e7ead11a',
      'native_key' => 4,
      'filename' => 'modResource/3b0d30695aecc1f45decd6ac0b85165e.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3e72c2b16f5944ca418cbd61cf92fe47',
      'native_key' => 5,
      'filename' => 'modResource/0fbc876a658b319b3de8124f3ec5f2b8.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ba72647c170aeac0763ddf3f902fd4ad',
      'native_key' => 6,
      'filename' => 'modResource/512a914b2b4df1ecaa0015e868bb49a5.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '242e933bc37b19115a928d6b689a064c',
      'native_key' => 7,
      'filename' => 'modResource/8e0b9d7596036962d725af4cdaa29c40.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '5d4215ed0bc1862a2bde73b9929929dc',
      'native_key' => 8,
      'filename' => 'modResource/b24efc09f91e884f230018625b1ccc51.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '26151a26e89803d83d7769adcbcec1ab',
      'native_key' => 9,
      'filename' => 'modResource/596bc2acf1de890510899af7373c9a61.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b6ca3ec665f75e9249ded6b89710dcc0',
      'native_key' => 10,
      'filename' => 'modResource/8a792350ff45b04a5753c90182cc2220.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0004bb7db65447c81278dee098d1b36a',
      'native_key' => 11,
      'filename' => 'modResource/1e2720e52956dad883d832e5a43e9ad2.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '84c9e26aa2c71c129b8890fc6914c1a0',
      'native_key' => 12,
      'filename' => 'modResource/19c57df52b3268debdbe8331412c8fe0.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '5f8bde973eb15d5f2752f4d904ea1f8d',
      'native_key' => 13,
      'filename' => 'modResource/693458e221c50c5c1a77f12016648b49.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);