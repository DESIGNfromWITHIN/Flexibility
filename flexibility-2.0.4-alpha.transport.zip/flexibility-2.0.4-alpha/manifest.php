<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.4-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-2.0.4-alpha.transport" and upload it to "<your_modx_install>/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.4-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a278ecec9363ea70d1d18f38963f7085',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/cdccce255b763fe542a9ff8e65fd42d4.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2aac4eeb5ad59fc62df06b6ce5259d29',
      'native_key' => '2aac4eeb5ad59fc62df06b6ce5259d29',
      'filename' => 'xPDOTransportVehicle/2074cb02818e721b0a5adc1bb9de92d2.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '96f0fccafc5e9cd68b3814cb9b71c97f',
      'native_key' => '96f0fccafc5e9cd68b3814cb9b71c97f',
      'filename' => 'xPDOTransportVehicle/966ae736c6f3c5b80c150931defdf8fa.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '55e7dab7e180de4dc1ca63c4cf557a3f',
      'native_key' => '55e7dab7e180de4dc1ca63c4cf557a3f',
      'filename' => 'xPDOTransportVehicle/13e861b27aa1c42fadb368bee9207655.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0f09d9eaf48eb005b809a715cf22db97',
      'native_key' => '0f09d9eaf48eb005b809a715cf22db97',
      'filename' => 'xPDOTransportVehicle/821cc90fcf6472a93902bdbbbde5ca5f.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5bb71ca936d3fade236b75fe2d38f498',
      'native_key' => '5bb71ca936d3fade236b75fe2d38f498',
      'filename' => 'xPDOTransportVehicle/b8bd4dec5ff4508b8363f68b95b84023.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2f5627109d8d6db931eeaa1e07b39fb7',
      'native_key' => '2f5627109d8d6db931eeaa1e07b39fb7',
      'filename' => 'xPDOTransportVehicle/a607e4a8dc940a92633112222fd94360.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd4b32094cf1a9b1aebf6d613a4e371a3',
      'native_key' => 'd4b32094cf1a9b1aebf6d613a4e371a3',
      'filename' => 'xPDOTransportVehicle/fd7850066c39fbd197699d031519c599.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ce47b4ab4e5622dcc03b9d8b9e96d9e8',
      'native_key' => 'ce47b4ab4e5622dcc03b9d8b9e96d9e8',
      'filename' => 'xPDOTransportVehicle/e1101829e1a93bca2ce8e68c8fe66377.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '699917d448a6eb25e2b6e2ccac2b7259',
      'native_key' => '699917d448a6eb25e2b6e2ccac2b7259',
      'filename' => 'xPDOTransportVehicle/b532b71fcdc3a3c16cb41b663372ce20.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '885c89fb6c34d8d2452a4b5f9953d37a',
      'native_key' => 1,
      'filename' => 'modCategory/2749998194063028629de00867a640f7.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '9ccbb146c37d157f088802793b1c6a4d',
      'native_key' => 1,
      'filename' => 'modResource/550a4907e4b6a7ae5f491dac66e340d4.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '00fee0bbe5b4b3153b2c173810082fed',
      'native_key' => 2,
      'filename' => 'modResource/45eef593ac537451f571d3f951e6cc83.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '66e72986bb1875e21cc8e42a98b87c04',
      'native_key' => 3,
      'filename' => 'modResource/ac998d3c952379f0d54880e2069fa698.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '96de131637cceaf2d52bc2da1264e8b1',
      'native_key' => 4,
      'filename' => 'modResource/8e8e557724e8dbc9088fea32e3c6904b.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a52b1b2ba9ad52b384cbe1617ce7ec9a',
      'native_key' => 5,
      'filename' => 'modResource/325c2a219c1edc3218b0d259c75c2556.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '89b78cddf7809b919cc14ffa7bff324d',
      'native_key' => 6,
      'filename' => 'modResource/c7a35354e59eb4d89315fb30a89a4b2c.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '6e63198f87836463e73ec1b8e9eed99c',
      'native_key' => 7,
      'filename' => 'modResource/09914c4f00e42e2f8094dd19231bd2f8.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '8252130a73c19aaf7aa3f178ab8e2f1c',
      'native_key' => 8,
      'filename' => 'modResource/36bf67ebf1e068ee6c4c0299aecd0afd.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b2da1605c88092a6a0853d0b11be1f5b',
      'native_key' => 9,
      'filename' => 'modResource/0b4ef3a370270e15503ac1ab81b625bb.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '580a3155fe4beac34340dee0c6691f9d',
      'native_key' => 10,
      'filename' => 'modResource/c453adccd60d14a1f33ad881de5a7c53.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd72113aad10210d9c24b3d4dd00118a6',
      'native_key' => 11,
      'filename' => 'modResource/44c65a5d3f78e3fa8525f6c0a01c1c54.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '6de91241b1217d8c22333c7431df892b',
      'native_key' => 12,
      'filename' => 'modResource/e74f9b3ed8e992580486fcf8fbec3b03.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e5d86aa4181b74028714904b9d2e4b20',
      'native_key' => 13,
      'filename' => 'modResource/bfa0b15a071a12c06ec2230b321002f6.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);