<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.4-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-2.0.4-alpha.transport" and upload it to "<your_modx_install>/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.4-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '232c53f82d5beae8b70e05d42b0d3610',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/ca215a60fc0d5d52a153077d4fe45e3d.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3f63e93f929960d41463b299b90d0a5f',
      'native_key' => '3f63e93f929960d41463b299b90d0a5f',
      'filename' => 'xPDOTransportVehicle/5ec12d6acb321562fffbd9300bbecf87.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '41ba62192603fe21de591b96feba756d',
      'native_key' => '41ba62192603fe21de591b96feba756d',
      'filename' => 'xPDOTransportVehicle/1faa907a24e55205d91af2071377e0aa.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'be7724a9a10a8a3c254f5053c19263d4',
      'native_key' => 'be7724a9a10a8a3c254f5053c19263d4',
      'filename' => 'xPDOTransportVehicle/f86495d9114def88614f684bcf6e693e.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8916d9b451f13ff898c126b478af497e',
      'native_key' => '8916d9b451f13ff898c126b478af497e',
      'filename' => 'xPDOTransportVehicle/88712f005094e76fe81cfad9293c7434.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9ba39db803cb1cdeada1346de060f3c7',
      'native_key' => '9ba39db803cb1cdeada1346de060f3c7',
      'filename' => 'xPDOTransportVehicle/4ffd10071c2670e5112cdccd46080bcd.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9ac56d908d2c3f73a755421eaa925721',
      'native_key' => '9ac56d908d2c3f73a755421eaa925721',
      'filename' => 'xPDOTransportVehicle/1a71b513772bdf3c6a34012730b76213.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'bb22597a2fb937b4743f0d83592977c2',
      'native_key' => 'bb22597a2fb937b4743f0d83592977c2',
      'filename' => 'xPDOTransportVehicle/d4ee2fd3c264ed03d1ba68f01a443832.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8a93286acec0e3353dc36aece5b09ac2',
      'native_key' => '8a93286acec0e3353dc36aece5b09ac2',
      'filename' => 'xPDOTransportVehicle/a69f1051ec5b8228cff315f92f4585c3.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '286b70b421ab154c02623b429e8f3fbc',
      'native_key' => '286b70b421ab154c02623b429e8f3fbc',
      'filename' => 'xPDOTransportVehicle/dc0174b244b01bf5ac1961c927eaaf65.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '735909193d49c2e4aea619580e08031c',
      'native_key' => 1,
      'filename' => 'modCategory/8dabc4efd67e29e656e2a2c4bd3af9f3.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '434129b719d5534d8668345ecce9f29e',
      'native_key' => 1,
      'filename' => 'modResource/960f66aba14408333e99a28123cc84f5.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '20b4983d9788b9e13341c1a021f43aaf',
      'native_key' => 2,
      'filename' => 'modResource/b1f1dbecca20d43415a15881f45bcd99.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '616582a9a19fd9d2d28b60bf96cf7666',
      'native_key' => 3,
      'filename' => 'modResource/523b0a1925c7d64c2a047409ff4b5c1e.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '8bfa8e3c740bf7af54d868e07c8db93f',
      'native_key' => 4,
      'filename' => 'modResource/bdb7c0b97e488b18330d24f9752e1526.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '869ea302d267d7ed517eb6f09a6fbab8',
      'native_key' => 5,
      'filename' => 'modResource/664e2e5367f37db1c4380092e41972f0.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd03b0aef1779885958af77b566657a15',
      'native_key' => 6,
      'filename' => 'modResource/e0bd84b091c57eafe7ebb3f02a94a92d.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a52c9cb05654c9d1644bb1c8ed45bd89',
      'native_key' => 7,
      'filename' => 'modResource/0ddc2e9adbc13362e8e939d5aa635830.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4f3e39492d58b05e463fe343526f3c37',
      'native_key' => 8,
      'filename' => 'modResource/02e58e7832da93445fd1f235c90265a3.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f38f5843d6c7e35a1470d2a35f9d3a31',
      'native_key' => 9,
      'filename' => 'modResource/11694a009579464e6f988eeba5c83126.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '870049e5a505c8ce080593337c3d0105',
      'native_key' => 10,
      'filename' => 'modResource/e638e4b722d001b35801b980149ebaab.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4fd31807cb025b67f9ea14864c513882',
      'native_key' => 11,
      'filename' => 'modResource/ff8e205dc3cdfdd0da39e5355d612d06.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b8531086233ef6ba81d40e1769f589bc',
      'native_key' => 12,
      'filename' => 'modResource/d60264e1bb4b3e4d61325dda5e692425.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '17c73083dc6150c077ac5f39d95942c4',
      'native_key' => 13,
      'filename' => 'modResource/e15a0d830614825659ae0a99da1d7d2a.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);