<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.4-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-2.0.4-alpha.transport" and upload it to "<your_modx_install>/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.4-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ea11d8654b31babf12d67580b3d99b4c',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/af7fb10bca7a942c2e7f1d2295ac5fd6.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c1d990413ce3832c122c4c3cc31127c3',
      'native_key' => 'c1d990413ce3832c122c4c3cc31127c3',
      'filename' => 'xPDOTransportVehicle/a1a24b2dabe1ad5382b2e67c32446e73.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'af8d3afab58f8bb40d25b14a8c68264a',
      'native_key' => 'af8d3afab58f8bb40d25b14a8c68264a',
      'filename' => 'xPDOTransportVehicle/4edfe025dc22ad2615585c8ee53e0768.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '78920fb4f5039508e645e57888c99576',
      'native_key' => '78920fb4f5039508e645e57888c99576',
      'filename' => 'xPDOTransportVehicle/067ff951c823c2cfc43edfbe414cdbd4.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8fc4e0e9939022f135ec91510202c65a',
      'native_key' => '8fc4e0e9939022f135ec91510202c65a',
      'filename' => 'xPDOTransportVehicle/fbed939a28b49b32c456f8f4f1c9863b.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0cf9723416addde4137f0e8ee40433b7',
      'native_key' => '0cf9723416addde4137f0e8ee40433b7',
      'filename' => 'xPDOTransportVehicle/66b6dc9fb3cc89a9efc16b870a6987d2.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '770e4e41cdea8378d0be333a319c3ce8',
      'native_key' => '770e4e41cdea8378d0be333a319c3ce8',
      'filename' => 'xPDOTransportVehicle/704626a3df49272750eac63bb56a3419.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '07d882f78840950ee0f518a755b58732',
      'native_key' => '07d882f78840950ee0f518a755b58732',
      'filename' => 'xPDOTransportVehicle/506540b683e281894a1501c4f9a81532.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3612231b272ed820afaf205ced6b9d0f',
      'native_key' => '3612231b272ed820afaf205ced6b9d0f',
      'filename' => 'xPDOTransportVehicle/296916a8eaef984fa9a8a9e1131483df.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '66f8692641dfc80ef84d5e7b086fb017',
      'native_key' => '66f8692641dfc80ef84d5e7b086fb017',
      'filename' => 'xPDOTransportVehicle/52b13689f5bb89e3a20d6c431e624a1b.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ddd887f67685c719b1453b2d59078809',
      'native_key' => 1,
      'filename' => 'modCategory/421121d9fd9ca59a3444094ba97a49c9.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1b573bfc01b313848b66f68197c3e1c3',
      'native_key' => 1,
      'filename' => 'modResource/d9c745d6bf59577eda7ca7ed1672d9bc.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f173aeb7cdb3be314999f1c385a1de23',
      'native_key' => 2,
      'filename' => 'modResource/37d1b8df71488a23dd8bf23e7e3d2c70.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'cc3422f86a487f34d3ab464011cb38ea',
      'native_key' => 3,
      'filename' => 'modResource/ec91e968aa8c7669bd30d7d86888cadf.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e541e9d6d6c0811cedc624b30f43db9d',
      'native_key' => 4,
      'filename' => 'modResource/1c53b45e74b6131bcc338a0c3cfbba45.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '47ab9d8993b2737b940a43b3b29288a0',
      'native_key' => 5,
      'filename' => 'modResource/cadb59633bd82eaecd94574e6421e4e3.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'de883f1b212e55ad756af9c6bf6a9a4b',
      'native_key' => 6,
      'filename' => 'modResource/83570bc3aeb727549ace28a860c6c1b2.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'deca3c6f8cf2721c05d7a18227684b43',
      'native_key' => 7,
      'filename' => 'modResource/f3928a1c88de4d4f8d30c596ee8d028f.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4f01e065d8d8d20f3014d780285aefa3',
      'native_key' => 8,
      'filename' => 'modResource/4a24afcb25dd78c46f9901a2e74276bf.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '68c60d9d3a85536016a2b4d54f4a635a',
      'native_key' => 9,
      'filename' => 'modResource/fd2b68c83db470d06fd0a3b87471d092.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ca39f1d186614980efca23f9fdcd54ae',
      'native_key' => 10,
      'filename' => 'modResource/fd766f504bafd792b20a23162d256cc2.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1868126fae3f193395f286b3b8695b18',
      'native_key' => 11,
      'filename' => 'modResource/07851485147d42ae7530e20f56268a98.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4a886cc903d6470547e2373d791a961a',
      'native_key' => 12,
      'filename' => 'modResource/d78f4ee1bd80fb6a7444955b79e48907.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '417fbd9c2e7d71f22667f9e507518505',
      'native_key' => 13,
      'filename' => 'modResource/f75d6eaf90941ee9880ff62b07b23e49.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);