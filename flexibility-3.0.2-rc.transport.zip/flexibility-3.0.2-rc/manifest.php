<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 3.0.2-rc
http://flexibilitymodx.com/

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation 3.2" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-3.0.2-rc.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-3.0.2-rc.transport (6 november 2012)
====================================
- Flexibility is a Release Candidate now!
- Updated to Foundation 3.2
- Changed UPDATE_OBJECT to FALSE (xPDOTransport::UPDATE_OBJECT => false), should prevent overwriting content on existing Flexibility installs.
- Added slide content
- Updated formit to 2.1.2-pl
- Updated getresources to 1.5.1-pl
- Updated migx to 2.3.2-pl

flexibility-3.0.1-alpha.transport (3 september 2012)
====================================
- Updated to Foundation 3.1.1
- Tested for MODX Revolution 2.2.5-pl

flexibility-3.0.0-alpha.transport (16 august 2012)
====================================
- Updated to Foundation 3.0

flexibility-2.1.1-alpha.transport (16 august 2012)
====================================
- Updated FormIt to formit-2.1.1-pl.transport
- Updated Gallery to gallery-1.5.2-pl.transport
- Updated GetResources to getresources-1.5.0-pl.transport
- Updated MIGX to migx-2.3.0-pl.transport
- Updated SimpleSearch to simplesearch-1.6.0-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport
- Updated TinyMCE to tinymce-4.3.3-pl.transport

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-3.0.2-rc/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '83d642ee25a247f9c1eea00cc7246e5b',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/aa7296e6a1403686e3977a92f4b86571.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5fde2bd5c93afb1d1b29f13bb1c1ad02',
      'native_key' => '5fde2bd5c93afb1d1b29f13bb1c1ad02',
      'filename' => 'xPDOTransportVehicle/d7b14fc6e5198b1eb99fe3c3258db367.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3829b569024441a44a9ad4b9310553a0',
      'native_key' => '3829b569024441a44a9ad4b9310553a0',
      'filename' => 'xPDOTransportVehicle/bbedc0413f75ba680822e0c75e11c1bf.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ffd4b6b251de7af6f529d981f64f1df6',
      'native_key' => 'ffd4b6b251de7af6f529d981f64f1df6',
      'filename' => 'xPDOTransportVehicle/845d125209f6d5b8a07778fb17ba81e7.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '379ef5ec8748e63e4924266727a1761d',
      'native_key' => '379ef5ec8748e63e4924266727a1761d',
      'filename' => 'xPDOTransportVehicle/7776399fe791fbf6f06106dcfd71ff12.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7d73114eebe4b4deab12c39774b79525',
      'native_key' => '7d73114eebe4b4deab12c39774b79525',
      'filename' => 'xPDOTransportVehicle/488a3834ab43a1ebf345caf2444aa13f.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7c36328f305aadc262d861da84995b6e',
      'native_key' => '7c36328f305aadc262d861da84995b6e',
      'filename' => 'xPDOTransportVehicle/eb6006efaf0c8c18d7352c0dde68e35d.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5e200593880b0663e4a0ae2e887443cd',
      'native_key' => '5e200593880b0663e4a0ae2e887443cd',
      'filename' => 'xPDOTransportVehicle/44e786db23c65a88c11b521e1eecbd10.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9b31f8941d55ce77fbd98d5eab5ae76e',
      'native_key' => '9b31f8941d55ce77fbd98d5eab5ae76e',
      'filename' => 'xPDOTransportVehicle/a38aebe8cbfb1d3ed2902de2d412b386.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b0da8f908fecafe9554ff890f7bb0ff1',
      'native_key' => 'b0da8f908fecafe9554ff890f7bb0ff1',
      'filename' => 'xPDOTransportVehicle/b6dd2fd5c78d8316d664c533569733a9.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a73889de08e6624c3df003bb36e74b1e',
      'native_key' => 1,
      'filename' => 'modCategory/88087d7a0175572f478947cae5893bec.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fbaf7bf4dbdcf5ea5cb82f391377c931',
      'native_key' => 1,
      'filename' => 'modResource/df712b1bb4c6869415a84586ab51490f.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '608036dc9b5a9a28fd71e4563e017c74',
      'native_key' => 2,
      'filename' => 'modResource/5a1d23d88e971dad430d0c3b0ac31c6b.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd2e9e3dcae778ff8eeac406b149aa128',
      'native_key' => 3,
      'filename' => 'modResource/ff8e0e180f5639e9e6c321ebec04edae.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c3ca72597bc7aac799dca352e444327b',
      'native_key' => 4,
      'filename' => 'modResource/83c199b91558b57c64f472a2e1b765f6.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fd2dbf8b1d93e0ccbfe35887a052658f',
      'native_key' => 5,
      'filename' => 'modResource/6771d6238d95a7945f6334dd4af85713.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0e83159667dbde9b4f3447bc72e9f654',
      'native_key' => 6,
      'filename' => 'modResource/f611a9e8238a118a5157a154ae8c17b8.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'bc4f13a5ff31b386a144970d60a4d092',
      'native_key' => 7,
      'filename' => 'modResource/9a6c37bfa0dabb781db415cb41132e34.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '273c5f6b3c8ea60cf74d1bb20d8faa34',
      'native_key' => 8,
      'filename' => 'modResource/53f24abd01e940c337b46886c3d0e522.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c2bb54959c1ccb604c9aeeb04e8c39a7',
      'native_key' => 9,
      'filename' => 'modResource/b2d2c04119dcae1474b040c5f058ebc4.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'da29aa3a715c505a3831e0c9a37d2093',
      'native_key' => 10,
      'filename' => 'modResource/7cc5b41b35a7b64858718a6e569dc5cb.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'bf41d15071824e2d5ca0118526f213e0',
      'native_key' => 11,
      'filename' => 'modResource/60d9b4f13828186b91add1889e3ef313.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f2001a867220c1e3fbc0a46243c0700a',
      'native_key' => 12,
      'filename' => 'modResource/b24d2dbedaa7871509011e58eca88c0b.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3fd739d473e232e01a2c21f71b175fc1',
      'native_key' => 13,
      'filename' => 'modResource/47888d7bcfe71c6992b0852374699ec7.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);