<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.5-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package, unzip it and upload "flexibility-2.0.5-alpha.transport" to "<your_modx_install>/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.5-alpha.transport (8-2-2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.5-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '73aff24b38b6d03b0c4e0a0825a84778',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/5ea8f85922e6c4a66ead5f5aa9f532ec.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'cc947347e2176bf237fab5e9c3fe7de0',
      'native_key' => 'cc947347e2176bf237fab5e9c3fe7de0',
      'filename' => 'xPDOTransportVehicle/95076308844aec00858e89084c04e7c0.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7b36b4967f491afdc7c4c2ee78137131',
      'native_key' => '7b36b4967f491afdc7c4c2ee78137131',
      'filename' => 'xPDOTransportVehicle/a58783b0122f68ef9e28e4a6ebe68c46.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '23fb7c637bdaad7d6e9a413e901ec293',
      'native_key' => '23fb7c637bdaad7d6e9a413e901ec293',
      'filename' => 'xPDOTransportVehicle/33c445590072c999826db856019e8b2d.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '04b928ea20b501f510d4c4f3a6e9ec9c',
      'native_key' => '04b928ea20b501f510d4c4f3a6e9ec9c',
      'filename' => 'xPDOTransportVehicle/bcdd39ad514faffcdd356f48228170f3.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7a3d69ab2607c598ad4912fa0bfc48d7',
      'native_key' => '7a3d69ab2607c598ad4912fa0bfc48d7',
      'filename' => 'xPDOTransportVehicle/272abced86dddeb281dd46bdaf2a4262.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '357a7237faec0fb31726c467a6f8a1f4',
      'native_key' => '357a7237faec0fb31726c467a6f8a1f4',
      'filename' => 'xPDOTransportVehicle/503bd7d05beff27f6389235a172aa145.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '127f9dab8d31f3ff628c7131bbf6d5b6',
      'native_key' => '127f9dab8d31f3ff628c7131bbf6d5b6',
      'filename' => 'xPDOTransportVehicle/6f8c2056c7ca0de28325adffe8a53d2f.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7644d80ec72b53a0e4512e67bd472b53',
      'native_key' => '7644d80ec72b53a0e4512e67bd472b53',
      'filename' => 'xPDOTransportVehicle/2939a80fbb4fc38a9c4b4212bf51336f.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd6dcf27d0cf71f9b85b29060f183da62',
      'native_key' => 'd6dcf27d0cf71f9b85b29060f183da62',
      'filename' => 'xPDOTransportVehicle/0bcdc6aabd3b4870a863b1efed52742d.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e6711acd2beebf3329738ffef696a17b',
      'native_key' => 1,
      'filename' => 'modCategory/0efd8c664b804a0eac688b275c60a8d4.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ae94866aa64a6255e730e9fb80797202',
      'native_key' => 1,
      'filename' => 'modResource/c7c5f5a0dc5e11fcbfbd21980542eac3.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '32c6eff3dbccd53afff1b4453dd1e89d',
      'native_key' => 2,
      'filename' => 'modResource/19b858636a18de61c2cb67b0212176aa.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '77359e615f0cdb42b279197942e96e99',
      'native_key' => 3,
      'filename' => 'modResource/b64b6e435efb8668b2b0651f38a8e0e3.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd127a885ccb886543c26a90c4759eedb',
      'native_key' => 4,
      'filename' => 'modResource/ed8928ad4c8d68cd7b29b8bc27c1ff4a.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '616b1518acb269b108236141a9bab4c4',
      'native_key' => 5,
      'filename' => 'modResource/4fc81a763239b1e2d780132a282c3890.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0cdaa394160845c0955f7b1f4facdf03',
      'native_key' => 6,
      'filename' => 'modResource/66060b05d2ff39a4d1e8b23e35483321.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c4567e54774f078617228db5f1effbd0',
      'native_key' => 7,
      'filename' => 'modResource/d2ccc4e9fae93d2e9ea9f770aa556a0d.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '153399518dbcbb50676568fccc1f6424',
      'native_key' => 8,
      'filename' => 'modResource/8609abe8fe7ad7ca29b62dc4eb30d5d5.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4719deed6b5973139fe8fee747c3ca3a',
      'native_key' => 9,
      'filename' => 'modResource/e8bc0c5a996f21154b069ea0a8b69ffd.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '37ca2444a60fd02ae57715f49204fe5f',
      'native_key' => 10,
      'filename' => 'modResource/a29192b6a558e20d5d607ba459e719b7.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd08ca3ecb8881e0a4246850f7a5d57b9',
      'native_key' => 11,
      'filename' => 'modResource/2f285a8167a6530dc8f31e8949308841.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3cc33a563ed0d515789b951ffed38b66',
      'native_key' => 12,
      'filename' => 'modResource/9f29ad15f3dd7886c733d3b7502254b9.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '9f4742590839fe188cb429f10ad78f61',
      'native_key' => 13,
      'filename' => 'modResource/d8e4e51e9f8faf395465be1e2ee3c33c.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);