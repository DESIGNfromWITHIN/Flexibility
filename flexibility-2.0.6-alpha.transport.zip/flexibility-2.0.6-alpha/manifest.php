<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 2.0.6-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-2.0.6-alpha.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.6-alpha.transport (11-3-2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8-2-2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4-2-2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.6-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3101ed3901af2e8a894c010396ce2545',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/aec44b878bf6640556c9b5922b60259e.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a0aca81aba34b9c68df639b16dd4f182',
      'native_key' => 'a0aca81aba34b9c68df639b16dd4f182',
      'filename' => 'xPDOTransportVehicle/cf6b1ff8293f8bab6789a474172fb283.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '354bfb4f19203296ffc10029db631099',
      'native_key' => '354bfb4f19203296ffc10029db631099',
      'filename' => 'xPDOTransportVehicle/1ff8c715d0a9794d3e024640fcba4209.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4164ebf8efacf479746719112fe41387',
      'native_key' => '4164ebf8efacf479746719112fe41387',
      'filename' => 'xPDOTransportVehicle/d5ce90f7c5333efc6bb00044a9adf233.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'cb5b853886ee797b8feb464b94b93bdc',
      'native_key' => 'cb5b853886ee797b8feb464b94b93bdc',
      'filename' => 'xPDOTransportVehicle/a6ccc682dfcf84f2774f3ac5e270e14b.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e77acf9e715dbfc92dcc64389c6c6d12',
      'native_key' => 'e77acf9e715dbfc92dcc64389c6c6d12',
      'filename' => 'xPDOTransportVehicle/01eea15c9c6d4dfc1095fdbec80f0d07.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd95f27d233ef3cfff096fe56a8eda23e',
      'native_key' => 'd95f27d233ef3cfff096fe56a8eda23e',
      'filename' => 'xPDOTransportVehicle/b396eb7422efc9da0b8c199249a073f6.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '739aee07dc51ccb20add0774b563e470',
      'native_key' => '739aee07dc51ccb20add0774b563e470',
      'filename' => 'xPDOTransportVehicle/e752f86c763884bc3095f6bae93688f8.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'afe3fb0e9074f0c76571202bca33d769',
      'native_key' => 'afe3fb0e9074f0c76571202bca33d769',
      'filename' => 'xPDOTransportVehicle/76b50fda1743e1617b6142b93129cf6b.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '27634f405bad27d98031e79c4d019429',
      'native_key' => '27634f405bad27d98031e79c4d019429',
      'filename' => 'xPDOTransportVehicle/f9ab855cbeb59e2f4e01ade0402bd83a.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '62c0c0b3d9876510ec9611356723d281',
      'native_key' => 1,
      'filename' => 'modCategory/c00fc2410cc574b8fcc0c2999c485d43.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '082865551aa9c5da03bfecbda031480d',
      'native_key' => 1,
      'filename' => 'modResource/968c0bc410645cbf1ded984fd3315b07.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a2a9a2ac52d993e7b3181f4d1235f1d9',
      'native_key' => 2,
      'filename' => 'modResource/cc9fa67c00c6340d11541a04cec0d7c9.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '31cb138ebb5f9b273940496bbabe81d0',
      'native_key' => 3,
      'filename' => 'modResource/853d5d0091613d003069f6d7885e78e0.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f64979999eb2a8f9514f4fd3939cdcdd',
      'native_key' => 4,
      'filename' => 'modResource/3dd4abe0e0ffd3f07f71f3405a4a1d8d.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'bddbbd548293f4138b58fd81b093f353',
      'native_key' => 5,
      'filename' => 'modResource/1233f0109d8b254dde619e7b1d64f7e8.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '5920718d17dfd748ac5d178f372e32e2',
      'native_key' => 6,
      'filename' => 'modResource/3d712b618f53e6d835cd61c4e5067f19.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b0fd6e5efe2affed3eaa947489ed1b8c',
      'native_key' => 7,
      'filename' => 'modResource/701d90ea56e1d9dac89c576f1b2e6468.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'ae910590e350704fa916d7df0259f175',
      'native_key' => 8,
      'filename' => 'modResource/97346fa907dfe2d13f60d4c2401a4300.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'e14a88cefdb65a41741b7395d7a68167',
      'native_key' => 9,
      'filename' => 'modResource/071a727f0d8140fa88f8073f5646cd86.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '63979c70c8b28e2e90e99c581bee21c3',
      'native_key' => 10,
      'filename' => 'modResource/26167b6c47930b568732680a334cfa68.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '1eddba0ff17b7c3775fde97a491562f8',
      'native_key' => 11,
      'filename' => 'modResource/f5e9df6e979394b6e992582a67da3460.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '6338dd10b95728f403f7369b67f6ef8f',
      'native_key' => 12,
      'filename' => 'modResource/68f9b679ae4141a66e5ba69700f79e13.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '5edbbc4290a87bcfb6e0e1d770df623a',
      'native_key' => 13,
      'filename' => 'modResource/a15a47f76417ef0d10a6795c27596e3d.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);