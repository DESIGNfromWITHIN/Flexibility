<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => 'Flexibility - version 2.0.1-beta

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen (blog: http://designfromwithin.com - Twitter: MennoPP)


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download "flexibility-2.0.1-beta.transport" and upload it to "your_url/core/packages/"

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Logo"

2. An e-mail adress where you want to get mail from the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but will be added....
- special thanks to: Paul Irish and Divya Manian for all they\'ve done with HTML5Boilerplate
- https://github.com/paulirish/html5-boilerplate for the initial base and idea
- https://github.com/modernizr for MOdernizr
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.0.2-beta.transport (17-12-2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13-12-2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.0.2-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6da1b8857e774109bb586b299df78f67',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/80d3b9b9f7cf9330ac2eb799fe837f68.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b847467ec5188f9337e08b9b20ceb407',
      'native_key' => 'b847467ec5188f9337e08b9b20ceb407',
      'filename' => 'xPDOTransportVehicle/19969f8d224974e46d4d72b8061464cb.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ed85e3702cccab21f40836c00d7afceb',
      'native_key' => 'ed85e3702cccab21f40836c00d7afceb',
      'filename' => 'xPDOTransportVehicle/a2cb0fb8de574e2da7f9a971fb06a9c1.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd6c0930a8b5f9bf51a2c4036e7b0e017',
      'native_key' => 'd6c0930a8b5f9bf51a2c4036e7b0e017',
      'filename' => 'xPDOTransportVehicle/49dc4180ca6c2f924c4ce1205ab14b71.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3f2c3cf1b23e2284096b6bea2d5a9ce8',
      'native_key' => '3f2c3cf1b23e2284096b6bea2d5a9ce8',
      'filename' => 'xPDOTransportVehicle/73bb3a757f3e665bf1c33305597f16a2.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a9d5e9975d034cc1a86520de796fade2',
      'native_key' => 'a9d5e9975d034cc1a86520de796fade2',
      'filename' => 'xPDOTransportVehicle/8f90b48eb3c87840b9e5aa2d4227f7b5.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e5c733eba0bc29d293b41e193cc39136',
      'native_key' => 'e5c733eba0bc29d293b41e193cc39136',
      'filename' => 'xPDOTransportVehicle/23e3a4df0a5200480390b87c9ac3b69a.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'a3e9bb542d51f16a17c2930f6acbe704',
      'native_key' => 'a3e9bb542d51f16a17c2930f6acbe704',
      'filename' => 'xPDOTransportVehicle/8e4105c9cbdc2c82d02483da43d523a9.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b6907a1f2654a729a42010e0ee67c2cf',
      'native_key' => 'b6907a1f2654a729a42010e0ee67c2cf',
      'filename' => 'xPDOTransportVehicle/71a3a1b574248a86cde1b6fc7e07d62a.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8d3326b11b9ec84baf415626b07f02c3',
      'native_key' => '8d3326b11b9ec84baf415626b07f02c3',
      'filename' => 'xPDOTransportVehicle/d3d55c1d383624fd49cd7c5b9c41431c.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8d6507544bb0ab70dbb5884adda9b681',
      'native_key' => 1,
      'filename' => 'modCategory/0fe7d59b75c95785c17431322675a103.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '8605f484ee198ff91d9221609ade53b4',
      'native_key' => 1,
      'filename' => 'modResource/89fd1407e5a34cec02e9c8b8398b7234.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'fe1a5e9bda96f24cd14fd3f11ee0a4e7',
      'native_key' => 2,
      'filename' => 'modResource/3a5fc3070f5a102cdd6c8061952dd12c.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '05511cbb1749657ce38b34e06afed91b',
      'native_key' => 3,
      'filename' => 'modResource/b488c5686231cb7a3758e82cad5f5138.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c2fd07f9f1600869b4b7558df1010b09',
      'native_key' => 4,
      'filename' => 'modResource/019f371e8c2245ebb6dcdd89d761c693.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '945e44254612291da15a5c2ab086c894',
      'native_key' => 5,
      'filename' => 'modResource/a383e5e0f29938ad65c8f4e163c0d340.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f7482b79f56fcd3221aae0304999b377',
      'native_key' => 6,
      'filename' => 'modResource/3a0dda2ebb2c3ec94ef302192d999aed.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'f9302dd89c549dcf7383fe25460f6f89',
      'native_key' => 7,
      'filename' => 'modResource/bc98cd817f550dcbc8f0548e1dc6a651.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'aaa9bb2e987210282a2338f5a4b79705',
      'native_key' => 8,
      'filename' => 'modResource/e8c8142644ab3f1b89345302df5f844f.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '40cf3feb3f06e3ae96f60d9f305c76d3',
      'native_key' => 9,
      'filename' => 'modResource/c08c7e1ac799734add337fda906a52d0.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '27fc28985994540f03e76abf52c2872e',
      'native_key' => 10,
      'filename' => 'modResource/dc33f953068e77fffe6ed1d6b0a4116e.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c8d20f50fcb66bf8ce22dfe974f9c4ec',
      'native_key' => 11,
      'filename' => 'modResource/eeb723f18de5ab81d8ac272a8570f0ce.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '4ee02bfbc91f2c2189a28ee4d190b51e',
      'native_key' => 12,
      'filename' => 'modResource/735ff7b8e2b248ad1e8acda40f09c25d.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '538a7aa2c6b84256947557884c11446c',
      'native_key' => 13,
      'filename' => 'modResource/00d7e2863c99edb5d9f388f179f28688.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);