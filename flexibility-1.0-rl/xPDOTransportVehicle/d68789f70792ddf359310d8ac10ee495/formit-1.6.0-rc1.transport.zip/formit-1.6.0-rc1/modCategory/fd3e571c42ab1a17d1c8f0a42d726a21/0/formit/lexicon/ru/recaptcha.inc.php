<?php
$_lang['recaptcha.empty_answer'] = 'Слова введены неправильно. Пожалуйста, проверьте ваш ответ и повторите попытку.';
$_lang['recaptcha.incorrect'] = 'Код капчи был введён неправильно. Вернитесь назад и попробуйте снова. [[+error]]';
$_lang['recaptcha.mailhide_no_mcrypt'] = 'Для использования reCAPTCHA Mailhide у вас должен быть установлен PHP модуль mcrypt.';
$_lang['recaptcha.mailhide_no_api_key'] = 'Для использования reCAPTCHA Mailhide, вам надо получить публичный и личный ключи, это можно сделать на <a href="http://mailhide.recaptcha.net/apikey">http://mailhide.recaptcha.net/apikey</a>';
$_lang['recaptcha.no_api_key'] = 'Для использования reCAPTCHA вам надо получить API ключ на<a href="http://recaptcha.net/api/getkey">http://recaptcha.net/api/getkey</a>';
$_lang['recaptcha.no_remote_ip'] = 'For security reasons, you must pass the remote ip to reCAPTCHA';

