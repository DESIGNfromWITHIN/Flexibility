--------------------
Snippet: getResources
--------------------
Version: 1.3.0-pl
Released: March 28, 2011
Since: December 28, 2009
Author: Jason Coward <jason@modx.com>

A general purpose Resource listing and summarization snippet for MODX Revolution.

Official Documentation:
http://docs.modxcms.com/display/ADDON/getResources
