<?php

/**

 * migx

 *

 * @package migx

 * @language it

 */

//$_lang['mig_'] = '';

$_lang['mig_noitems'] = 'Nessun elemento trovato';
$_lang['mig_add'] = 'Aggiungi Elemento';
$_lang['mig_remove_confirm'] = 'Rimuovere Elemento?';
$_lang['mig_edit'] = 'Modifica';
$_lang['mig_remove'] = 'Rimuovi';
$_lang['mig_duplicate'] = 'Duplica';
$_lang['mig_preview'] = 'Preview';
$_lang['mig_save_resource'] = 'Before adding new items, you have to save this resource!';