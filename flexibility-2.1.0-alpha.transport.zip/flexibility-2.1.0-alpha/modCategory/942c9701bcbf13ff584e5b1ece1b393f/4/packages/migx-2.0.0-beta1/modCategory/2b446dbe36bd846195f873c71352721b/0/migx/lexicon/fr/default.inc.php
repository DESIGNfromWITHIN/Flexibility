<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */

//$_lang['mig_'] = '';


$_lang['mig_noitems'] = 'Aucun élément trouvé';
$_lang['mig_add'] = 'Ajouter un élément';
$_lang['mig_remove_confirm'] = 'Êtes-vous sûr de vouloir supprimer cet élément ?';
$_lang['mig_edit'] = 'Éditer';
$_lang['mig_remove'] = 'Supprimer';
$_lang['mig_duplicate'] = 'Dupliquer';
$_lang['mig_preview'] = 'Preview';
$_lang['mig_save_resource'] = 'Before adding new items, you have to save this resource!';