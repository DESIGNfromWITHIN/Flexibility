<?php return array (
  'e2d4c7b60cd7150542974c5970e3551e' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/assets/components',
    ),
  ),
);