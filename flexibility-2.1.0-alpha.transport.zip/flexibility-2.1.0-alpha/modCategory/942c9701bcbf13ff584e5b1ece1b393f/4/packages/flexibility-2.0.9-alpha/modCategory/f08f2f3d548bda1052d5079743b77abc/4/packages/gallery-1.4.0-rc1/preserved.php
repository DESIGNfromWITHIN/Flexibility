<?php return array (
  '352c1f39b60a9b7b6cc1da0b767f6734' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/core/components',
    ),
  ),
  '102bd8dd0001176ce6b2e92ceb203dd3' => 
  array (
    'criteria' => 
    array (
      'key' => 'xhtml_urls',
    ),
    'object' => 
    array (
      'key' => 'xhtml_urls',
      'value' => '1',
      'xtype' => 'combo-boolean',
      'namespace' => 'core',
      'area' => 'site',
      'editedon' => '0000-00-00 00:00:00',
    ),
  ),
);