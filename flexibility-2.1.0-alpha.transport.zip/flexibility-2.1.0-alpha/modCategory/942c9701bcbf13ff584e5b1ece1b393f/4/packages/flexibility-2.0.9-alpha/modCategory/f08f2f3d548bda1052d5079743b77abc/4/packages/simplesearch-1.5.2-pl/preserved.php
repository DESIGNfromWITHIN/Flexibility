<?php return array (
  '884a459cec0b30ec986fbaf844117af7' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/core/components',
    ),
  ),
);