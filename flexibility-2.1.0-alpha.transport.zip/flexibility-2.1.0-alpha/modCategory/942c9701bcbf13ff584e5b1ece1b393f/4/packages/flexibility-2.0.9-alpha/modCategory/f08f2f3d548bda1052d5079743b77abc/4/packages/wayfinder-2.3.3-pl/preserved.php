<?php return array (
  '4adadf5fc81965f5f741196fd6ac3cac' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/core/components',
    ),
  ),
);