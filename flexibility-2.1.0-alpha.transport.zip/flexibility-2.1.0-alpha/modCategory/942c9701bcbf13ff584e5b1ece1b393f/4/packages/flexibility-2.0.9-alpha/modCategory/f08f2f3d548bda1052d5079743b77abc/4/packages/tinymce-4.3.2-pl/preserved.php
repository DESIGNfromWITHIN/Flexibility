<?php return array (
  '51d45ac38677903221a8b53d9e2d819d' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/core/components',
    ),
  ),
);