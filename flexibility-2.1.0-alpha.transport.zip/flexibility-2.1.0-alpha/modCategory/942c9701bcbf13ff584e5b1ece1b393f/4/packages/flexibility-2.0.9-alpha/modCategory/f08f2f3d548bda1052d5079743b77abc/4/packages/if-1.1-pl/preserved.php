<?php return array (
  'a3e98eb64a1cc23f23b2687bec848dc6' => 
  array (
    'files' => 
    array (
      0 => 'D:/Dropbox/DESIGNfromWITHIN/SITES/Flexibility/core/components',
    ),
  ),
);