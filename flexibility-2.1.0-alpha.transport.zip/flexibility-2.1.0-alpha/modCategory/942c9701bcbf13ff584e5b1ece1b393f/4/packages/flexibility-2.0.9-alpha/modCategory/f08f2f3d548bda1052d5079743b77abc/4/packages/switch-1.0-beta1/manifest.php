<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '89a48ffd5545a3c9ebed348c29851c84',
      'native_key' => 'switch',
      'filename' => 'modNamespace/1a390d8210956cf999347c81f520caee.vehicle',
      'namespace' => 'switch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '44584c80a24fc1ebf090737eb99c8611',
      'native_key' => 1,
      'filename' => 'modCategory/ec362fd473e3cdb693c84d576b14ba82.vehicle',
      'namespace' => 'switch',
    ),
  ),
);