<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Flexibility
Copyright 2012 Menno Pietersen <info@designfromwithin.com>

Flexibility is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 
Flexibility is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with Flexibility (gpl-3.0.txt); if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA',
    'readme' => 'Flexibility - version 2.1.0-alpha

-----------------------------------------------------------------------------------------------------------
ABOUT
-----------------------------------------------------------------------------------------------------------

"Flexibility" is a HTML5/CSS3/jQuery based frontend MODx Revolution template based on the "Foundation" (http://foundation.zurb.com/).
With this package you will have a fully functional website with a dropdown nav, contact form, slider and a image gallery.

"Flexibility" is designed and coded by Menno Pietersen
Portfolio & blog: DESIGNfromWITHIN http://designfromwithin.com
Twitter: MennoPP https://twitter.com/MennoPP


-----------------------------------------------------------------------------------------------------------
QUICKSTART        PLEASE READ THIS 
-----------------------------------------------------------------------------------------------------------

1. Install MODx Revolution on your website.

2. download the package and upload the "flexibility-2.1.0-alpha.transport.zip" file to "<your_modx_install>/core/packages/" (You only need the transport.zip file, do not unzip it yourself)

3. Install the "Flexibility" package: Go to "System" > "Package Management" > "Add New Package" > "Search Locally for Packages" > "Yes".

THAT IS ALL!
(to be sure clear your cache > "Site" > "Clear Cache")

-----------------------------------------------------------------------------------------------------------
ADDING AND CHANGING CONTENT
-----------------------------------------------------------------------------------------------------------

Your MODX website needs three main thing:

1. A Logo.
- Add this under "Resources" > "Site settings" > "Template Variables" tab > "Logo"

2. E-mail adress for the contact form.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Email adress for the contactform"

3. Content for the footer.
- Select how many footer boxes you want under "Resources" > "Site settings" > "Template Variables" > "Footer boxes"
- Add content for each footer box under "Resources" > "Site settings" > "Template Variables" > "Footer-content box 1", "Footer-content box 2", "Footer-content box 3" and "Footer-content box 4"

4. (optional) Slides/content for the slider.
- Add this under "Resources" > "Site settings" > "Template Variables" > "Slider items"
- Activate the slider on any page under: "Template Variables".

5. Other page content is added the normal way on each resource, see the "Template Variables" tab on each resource for extra options. 

-----------------------------------------------------------------------------------------------------------
UPDATE instructions:
-----------------------------------------------------------------------------------------------------------

- All sub-packages (like Wayfinder) are installed by Flexibility and you will be able to remove/update each sub-package under "System" > "Package Management".
- You can update the package via package installer, download the new version and place it in:
[base_path}/core/packages/
Update the package under "System" > "Package Management"

-----------------------------------------------------------------------------------------------------------
CREDITS:
-----------------------------------------------------------------------------------------------------------

ALL supporters and contributors:
- http://foundation.zurb.com/
- http://html5boilerplate.com/ (not used but got me started....)
- the MODX Revolution team for the whole MODX system
- Anselm Hannemann for the MODx Boilerplate, http://anselm.novolo.de/
- The MODX community for all the great tips and support!

-----------------------------------------------------------------------------------------------------------
BUGS and FEATURE REQUESTS:
-----------------------------------------------------------------------------------------------------------

Please post on GitHub (https://github.com/DESIGNfromWITHIN/Flexibility) or e-mail me at: info@designfromwithin.com',
    'changelog' => 'Changelog for Flexibility

flexibility-2.1.0-alpha.transport (2 august 2012)
====================================
- Fixed the Image slider (many thanks to: Designforge)
- Updated MIGX to migx-2.2.3-pl.transport

flexibility-2.0.9-alpha.transport (7 july 2012)
====================================
- Added the first commit adding the In-Field-Labels jquery plugin (many thanks to: frogabog)

flexibility-2.0.8-alpha.transport (5 june 2012)
====================================
- Fixed the php thumb bug and gallery
- Added the latest version of fancybox.js
- Updated packages Articles to articles-1.6.1-pl.transport
- Updated packages Simple Search to simplesearch-1.6.0-pl.transport
- Updated packages MIGX to migx-2.0.1-pl.transport
- Updated packages Gallery to gallery-1.5.0-pl.transport
- Added "\'gallery.thumbs_prepend_site_url\' => true" setting to the install
- Added "\'phpthumb_allow_src_above_docroot\' => true" setting to the install

flexibility-2.0.6-alpha.transport (11 march 2012)
====================================
- Changed TV order
- Removed unwanted code
- Added Public License
- Remove includeTemplate code, now using Media Sources
- Updated packages (FormIt, getResources, simplesearch, TinyMCE)
- Updated Foundation Framework to 2.2
- Fixed small dropdown issue

flexibility-2.0.5-alpha.transport (8 febuary 2012)
====================================
- Fixed sub-page-2 bug (thanks Showa!)

flexibility-2.0.4-alpha.transport (5-2-2012)
====================================
- Template variables are now added to the correct template.
- Ready for ALPHA testing!

flexibility-2.0.3-beta.transport (4 febuary 2012)
====================================
- Using just one category now.
- Fixed MIGX bug.

flexibility-2.0.2-beta.transport (17 december 2011)
====================================
- Added MIGX TV\'s for adding slides to the image slider.

flexibility-2.0.1-beta.transport (13 december 2011)
====================================
- First version online!',
    'setup-options' => 'flexibility-2.1.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6d3dbdcb60ed8e400f47eb0f596987a6',
      'native_key' => 'flexibility',
      'filename' => 'modNamespace/1a2156dc69a09a7b9f127b17f1e62728.vehicle',
      'namespace' => 'flexibility',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ceaa0951e77bb736a45e29c2ffcddd4e',
      'native_key' => 'ceaa0951e77bb736a45e29c2ffcddd4e',
      'filename' => 'xPDOTransportVehicle/65767361104f6af051832f98148edddc.vehicle',
      'namespace' => 'flexibility',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '775c6dd0fc1eccf7bac509c734933bf1',
      'native_key' => '775c6dd0fc1eccf7bac509c734933bf1',
      'filename' => 'xPDOTransportVehicle/ebc0a265af7cee0132527eaefbf377f3.vehicle',
      'namespace' => 'flexibility',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5e8b31ad17ace358c01a194a1083c5eb',
      'native_key' => '5e8b31ad17ace358c01a194a1083c5eb',
      'filename' => 'xPDOTransportVehicle/c8421c5c58ec1c51cd757708c8da15a0.vehicle',
      'namespace' => 'flexibility',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f5e1b71e6e913348a723ddfeff9a92bb',
      'native_key' => 'f5e1b71e6e913348a723ddfeff9a92bb',
      'filename' => 'xPDOTransportVehicle/4cbd5a61d096b89f0d89bdc2fe370039.vehicle',
      'namespace' => 'flexibility',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4d6c138964781721b7b6da775dc97539',
      'native_key' => '4d6c138964781721b7b6da775dc97539',
      'filename' => 'xPDOTransportVehicle/f4a1f6b812baeee5712b76f708796f50.vehicle',
      'namespace' => 'flexibility',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f394cf291c966541c9ed7315d6128684',
      'native_key' => 'f394cf291c966541c9ed7315d6128684',
      'filename' => 'xPDOTransportVehicle/be50b54d1492f5ba106c0766b9615af5.vehicle',
      'namespace' => 'flexibility',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'cd9c792f1b614011a180f228fceadecc',
      'native_key' => 'cd9c792f1b614011a180f228fceadecc',
      'filename' => 'xPDOTransportVehicle/087cbf138bceb6468f048919e258e5c2.vehicle',
      'namespace' => 'flexibility',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd66b54b181148331a9f837c2e6a502c4',
      'native_key' => 'd66b54b181148331a9f837c2e6a502c4',
      'filename' => 'xPDOTransportVehicle/6b228935961c42fba71f8316a9f031dc.vehicle',
      'namespace' => 'flexibility',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c9bee179373975790026ccfaed48a083',
      'native_key' => 'c9bee179373975790026ccfaed48a083',
      'filename' => 'xPDOTransportVehicle/25c68e78105bd2f3e781446221e824d1.vehicle',
      'namespace' => 'flexibility',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9d4df46832d2d2fd8f9c9a69a3e8c0b4',
      'native_key' => 1,
      'filename' => 'modCategory/942c9701bcbf13ff584e5b1ece1b393f.vehicle',
      'namespace' => 'flexibility',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3d2743918755609608bec7a2ae9ee4db',
      'native_key' => 1,
      'filename' => 'modResource/a69d61adbf5394682db7da09ca77639a.vehicle',
      'namespace' => 'flexibility',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '0fa2dc7216c51846c8601889db752083',
      'native_key' => 2,
      'filename' => 'modResource/56b6234b9f212da09d6cfba6cc41f817.vehicle',
      'namespace' => 'flexibility',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '3d858520bebdd523ed9ed282475309ff',
      'native_key' => 3,
      'filename' => 'modResource/8ec988f237c074893660425a29ffdaa6.vehicle',
      'namespace' => 'flexibility',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '73207ef16146cbfd4f1d394cdafcaec9',
      'native_key' => 4,
      'filename' => 'modResource/b706308f52860468f632c9ddfc14fbe9.vehicle',
      'namespace' => 'flexibility',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'd7565bb2b040d1c0de10b3227a5e2751',
      'native_key' => 5,
      'filename' => 'modResource/4d0ae3f49d151a6d489f358f4dcc30df.vehicle',
      'namespace' => 'flexibility',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'a0a4235f3bf7d9f015d3b969985870b0',
      'native_key' => 6,
      'filename' => 'modResource/23f3ad7ff9e7488b73ebed85b74ae641.vehicle',
      'namespace' => 'flexibility',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '8c8314ce493b3cb5a97dcfca9c95a25b',
      'native_key' => 7,
      'filename' => 'modResource/32cd6593d26c96d528f0d0c9b0de3036.vehicle',
      'namespace' => 'flexibility',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'b22df0676cccc278b97a7faf63e26735',
      'native_key' => 8,
      'filename' => 'modResource/501fc2f0df13ce495fa924894a7033d0.vehicle',
      'namespace' => 'flexibility',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '89d47cd95c56d5d9e899267fdd27262d',
      'native_key' => 9,
      'filename' => 'modResource/3745ef863519f60bd0821df5ece6d3e6.vehicle',
      'namespace' => 'flexibility',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '9b897afcdf73ea59a57570e28d12a4c0',
      'native_key' => 10,
      'filename' => 'modResource/7041df58f656bc579c6877d83928f227.vehicle',
      'namespace' => 'flexibility',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'c80abb099869a1f9729916151bb02dc0',
      'native_key' => 11,
      'filename' => 'modResource/0e80459cd6a8be1536c2d9c072d2707e.vehicle',
      'namespace' => 'flexibility',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => 'bda44bd7695e46177103fbfcb1b99576',
      'native_key' => 12,
      'filename' => 'modResource/8ec49326133d00d4acf7a87e6528a26d.vehicle',
      'namespace' => 'flexibility',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modResource',
      'guid' => '2b7f7e0a54b367b3ea2730705ce25e53',
      'native_key' => 13,
      'filename' => 'modResource/827ecc7b7ce8a96d41165d670c0e1711.vehicle',
      'namespace' => 'flexibility',
    ),
  ),
);